# Canvas UGC Content Analyzer

## Overview

This application is a Canvas UGC (User-Generated Content) analyzer designed for the Creator Current Academy. It allows content creators to upload videos, analyze their UGC content against Canvas UGC standards, and receive detailed feedback on their storytelling techniques. The system evaluates videos across multiple dimensions including emotion, convincability, persuasion, trust, and enthusiasm to help creators improve their content creation skills.

## User Preferences

- Preferred communication style: Simple, everyday language.
- Design preference: Various shades of green for color scheme with elegant, minimal, classic design aesthetic
- Authentication: Social authentication only (no access codes required)

## System Architecture

This is a full-stack web application built with a modern TypeScript stack, featuring:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Build Tool**: Vite for fast development and building

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ESM modules
- **API Design**: RESTful API endpoints
- **File Handling**: Multer for video file uploads
- **Session Management**: Express session with PostgreSQL store

### Database Architecture
- **Primary Database**: PostgreSQL via Neon serverless
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations
- **Connection**: Serverless connection pooling via @neondatabase/serverless

## Key Components

### Authentication System
- **Provider**: Replit Auth integration with OpenID Connect
- **Session Storage**: PostgreSQL-backed sessions using connect-pg-simple
- **Access Control**: Invitation code system for user onboarding
- **User Management**: Complete user profile and settings management

### Video Processing Pipeline
- **Upload**: Multer-based file upload with video format validation
- **Storage**: Local filesystem storage with 100MB file size limit
- **Analysis**: AI-powered content analysis system
- **Scoring**: Multi-dimensional scoring system (emotion, convincability, persuasion, trust, enthusiasm)

### UI/UX Design
- **Design System**: shadcn/ui components with Radix UI primitives
- **Theme**: Green color scheme with various shades (emerald, forest, sage, mint)
- **Color Palette**: Custom CSS variables for green gradients and accents
- **Responsiveness**: Mobile-first responsive design
- **Accessibility**: ARIA-compliant components from Radix UI
- **Visual Style**: Elegant, minimal, classic design with gradient backgrounds

### Content Management
- **Canvas Methods**: Support for different UGC content styles (Facetime, Lazy Girl, Tutorial, Hot Girl Commentary, FOMO)
- **Analytics**: User performance tracking and metrics dashboard
- **Feedback System**: Detailed AI-generated feedback for content improvement
- **Social Media Preview**: Real-time preview of how videos appear on TikTok, Instagram Reels, and YouTube Shorts
- **Format Optimizer**: Platform-specific video optimization with quality settings, auto-captions, and hook enhancement

## Data Flow

1. **User Authentication**: Users authenticate via Replit Auth (invitation codes removed)
2. **Video Upload**: Users upload videos with metadata (title, Canvas method)
3. **Content Analysis**: Videos are processed through a dual AI pipeline:
   - Lemonfox AI transcribes the video content
   - OpenAI GPT-4o analyzes the transcription for Canvas UGC quality metrics
   - Mac Persona GPT provides personalized coaching feedback
4. **Score Generation**: Multi-dimensional scores are calculated and stored
5. **Feedback Delivery**: Users receive both AI analysis and Mac's personalized coaching
6. **Progress Tracking**: Historical data is tracked for performance insights

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework

### AI Integration
- **openai**: GPT-4o model for Canvas UGC content analysis
- **Lemonfox AI**: Video transcription service (API key required)
- **Mac Persona GPT**: Expert Canvas UGC coach and comprehensive knowledge base
  - Deep understanding of Canvas UGC as story-first content framework vs traditional UGC
  - Evaluates content based on 5 core elements: Hook, Relatability, Story, Soft Sell, Delivery
  - Expertise in 6 Canvas methods with visual style guides: Facetime, Lazy Girl, Tutorial, Hot Girl Commentary, FOMO, Gatekeep/Bait
  - Advanced method stacking knowledge (e.g., Facetime + Gatekeep, Lazy Girl + Tutorial)
  - Provides specific feedback on scroll-stopping hooks, story-driven narratives, and conversion optimization
  - Balances virality with sales conversion using 30-second funnel framework (Grab → Trust → Show → Inspire)
  - "Sales in Disguise" philosophy - product as detail in corner, not subject of painting
  - Instagram Reels algorithm optimization expertise
  - References proven hook formulas and emotional triggers
  - Understands delivery nuances: voice modulation, facial expressions, tone matching
  - Focuses on FYP-native content for non-brand accounts
  - Views conversion metrics beyond views: saves, shares, group chat sends, organic reposts
  - Performance assessment criteria: facial expression, pacing, eye contact, energy matching
  - AI coaching capabilities: hook rating, story rewriting, tone matching, brand detection, method selection
  - Script review across 5 dimensions: emotional energy, pacing/rhythm, relatability, conversational tone, organic mentions
  - Trend adaptation: tracks emotional themes, hook structures, delivery shifts monthly
  - Final review checklist ensures tension-driven hooks, relatable arcs, natural delivery, organic product integration
  - Canvas Creator Mindset: 6 core truths about being the product before the product, story over script, emotional accuracy over perfection

### Authentication
- **openid-client**: OpenID Connect authentication
- **passport**: Authentication middleware
- **express-session**: Session management

### File Processing
- **multer**: File upload handling
- **ws**: WebSocket support for Neon database

### Development Tools
- **tsx**: TypeScript execution for development
- **vite**: Build tool and development server
- **esbuild**: Fast JavaScript bundler for production

## Deployment Strategy

### Development Environment
- **Hot Reloading**: Vite HMR for instant feedback
- **TypeScript**: Full type checking across the stack
- **Database**: Drizzle Kit for schema management and migrations

### Production Build
- **Frontend**: Vite static build output to dist/public
- **Backend**: esbuild bundle to dist/index.js
- **Database**: PostgreSQL via Neon with connection pooling
- **Assets**: Static file serving via Express

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **SESSION_SECRET**: Session encryption key
- **REPLIT_DOMAINS**: Allowed domains for Replit Auth
- **ISSUER_URL**: OpenID Connect issuer URL

The application is designed for deployment on Replit with integrated authentication and database services, but can be adapted for other cloud platforms with minimal configuration changes.