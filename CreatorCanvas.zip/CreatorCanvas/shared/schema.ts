import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  contentFocus: varchar("content_focus"),
  primaryPlatform: varchar("primary_platform"),
  accessCode: varchar("access_code"),
  detailedFeedback: boolean("detailed_feedback").default(true),
  emailNotifications: boolean("email_notifications").default(true),
  weeklyReports: boolean("weekly_reports").default(false),
  dataStorage: boolean("data_storage").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  title: varchar("title").notNull(),
  filename: varchar("filename").notNull(),
  fileUrl: varchar("file_url").notNull(),
  canvasMethod: varchar("canvas_method").notNull(),
  status: varchar("status").default("processing"), // processing, completed, failed
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const videoAnalyses = pgTable("video_analyses", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").references(() => videos.id).notNull(),
  overallScore: integer("overall_score"),
  emotionScore: integer("emotion_score"),
  convincabilityScore: integer("convincability_score"),
  persuasionScore: integer("persuasion_score"),
  trustScore: integer("trust_score"),
  enthusiasmScore: integer("enthusiasm_score"),
  aiFeedback: text("ai_feedback"),
  transcription: text("transcription"),
  behavioralSignals: jsonb("behavioral_signals"),
  macAnalysis: jsonb("mac_analysis"),
  pineconeVectorId: varchar("pinecone_vector_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const accessCodes = pgTable("access_codes", {
  id: serial("id").primaryKey(),
  code: varchar("code").unique().notNull(),
  isUsed: boolean("is_used").default(false),
  usedBy: varchar("used_by").references(() => users.id),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertVideo = typeof videos.$inferInsert;
export type Video = typeof videos.$inferSelect;
export type InsertVideoAnalysis = typeof videoAnalyses.$inferInsert;
export type VideoAnalysis = typeof videoAnalyses.$inferSelect;
export type InsertAccessCode = typeof accessCodes.$inferInsert;
export type AccessCode = typeof accessCodes.$inferSelect;

export const insertVideoSchema = createInsertSchema(videos).omit({
  id: true,
  userId: true,
  status: true,
  createdAt: true,
  updatedAt: true,
});

export const insertVideoAnalysisSchema = createInsertSchema(videoAnalyses).omit({
  id: true,
  createdAt: true,
});

export const insertAccessCodeSchema = createInsertSchema(accessCodes).omit({
  id: true,
  isUsed: true,
  usedBy: true,
  usedAt: true,
  createdAt: true,
});

export const updateUserSettingsSchema = createInsertSchema(users).pick({
  firstName: true,
  lastName: true,
  email: true,
  contentFocus: true,
  primaryPlatform: true,
  detailedFeedback: true,
  emailNotifications: true,
  weeklyReports: true,
  dataStorage: true,
});

export type InsertVideoType = z.infer<typeof insertVideoSchema>;
export type InsertVideoAnalysisType = z.infer<typeof insertVideoAnalysisSchema>;
export type InsertAccessCodeType = z.infer<typeof insertAccessCodeSchema>;
export type UpdateUserSettingsType = z.infer<typeof updateUserSettingsSchema>;
