# Canvas UGC Content Analyzer

An advanced AI-powered Canvas UGC video analysis platform designed to empower content creators with intelligent performance insights and optimization tools for the Creator Current Academy.

## Features

- **AI-Powered Video Analysis**: Uses OpenAI GPT-4o and Lemonfox AI to analyze Canvas UGC content
- **Multi-Dimensional Scoring**: Evaluates emotion, convincability, persuasion, trust, and enthusiasm
- **Canvas Method Support**: Supports different UGC styles (Facetime, Lazy Girl, Tutorial, Hot Girl Commentary, FOMO)
- **Social Media Preview**: Real-time preview for TikTok, Instagram Reels, and YouTube Shorts
- **Performance Dashboard**: Track progress and analytics across all video content
- **Mac Persona GPT**: Expert Canvas UGC coaching with comprehensive feedback

## Technology Stack

### Frontend
- React 18 with TypeScript
- Tailwind CSS + shadcn/ui components
- Wouter for routing
- TanStack Query for state management
- Vite for development and building

### Backend
- Node.js with Express.js
- TypeScript with ESM modules
- PostgreSQL with Drizzle ORM
- Multer for file uploads
- Express sessions with PostgreSQL store

### AI Integration
- OpenAI GPT-4o for content analysis
- Lemonfox AI for video transcription
- Mac Persona GPT for expert coaching

## Setup Instructions

### Prerequisites
- Node.js 18+ and npm
- PostgreSQL database
- OpenAI API key
- Lemonfox AI API key

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/canvas-ugc-analyzer.git
cd canvas-ugc-analyzer
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your actual values
```

4. Set up the database:
```bash
npm run db:push
```

5. Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5000`.

## Environment Variables

See `.env.example` for required environment variables:

- `DATABASE_URL` - PostgreSQL connection string
- `OPENAI_API_KEY` - OpenAI API key for content analysis
- `LEMONFOX_API_KEY` - Lemonfox AI API key for transcription
- `SESSION_SECRET` - Session encryption key
- `REPLIT_DOMAINS` - Allowed domains for authentication
- `ISSUER_URL` - OpenID Connect issuer URL

## Usage

1. **Upload Videos**: Upload your Canvas UGC videos through the upload interface
2. **AI Analysis**: Videos are automatically transcribed and analyzed for Canvas UGC quality
3. **Review Scores**: Get detailed scores across 5 dimensions with AI feedback
4. **Track Progress**: Monitor your improvement over time through the metrics dashboard
5. **Get Coaching**: Receive personalized feedback from Mac Persona GPT

## Project Structure

```
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   ├── pages/         # Page components
│   │   ├── hooks/         # Custom React hooks
│   │   └── lib/           # Utilities and configurations
├── server/                # Express backend
│   ├── routes.ts          # API routes
│   ├── storage.ts         # Database operations
│   └── auth.ts            # Authentication logic
├── shared/                # Shared types and schemas
└── uploads/               # File upload directory
```

## API Endpoints

- `GET /api/auth/user` - Get current user
- `POST /api/login` - Authentication login
- `POST /api/analyses` - Upload and analyze video
- `GET /api/analyses` - Get user's video analyses
- `GET /api/metrics/stats` - Get user performance stats
- `GET /api/metrics/canvas-methods` - Get Canvas method analytics

## Database Schema

The application uses PostgreSQL with Drizzle ORM. Key tables:
- `users` - User profiles and authentication
- `analyses` - Video analysis results and scores
- `videos` - Video metadata and file information

## Deployment

This project is designed for deployment on Replit with integrated authentication and database services, but can be adapted for other cloud platforms.

For production deployment:
1. Set up a PostgreSQL database
2. Configure environment variables
3. Build the application: `npm run build`
4. Start the production server: `npm start`

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit your changes: `git commit -m 'Add amazing feature'`
4. Push to the branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## License

This project is proprietary software developed for Creator Current Academy.# canvas-ugc-analyzer
