import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { 
  Instagram, 
  Play, 
  Smartphone, 
  Monitor,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Settings,
  Sparkles,
  AlertCircle,
  CheckCircle
} from "lucide-react";
import { SiTiktok } from "react-icons/si";
import { FormatOptimizer } from "./format-optimizer";

interface SocialMediaPreviewProps {
  videoId: number;
  videoUrl: string;
  title: string;
  canvasMethod: string;
}

interface PlatformSpecs {
  name: string;
  aspectRatio: string;
  maxDuration: number;
  recommendedDuration: number;
  resolution: string;
  fileSize: string;
  tips: string[];
}

const platformSpecs: Record<string, PlatformSpecs> = {
  tiktok: {
    name: "TikTok",
    aspectRatio: "9:16",
    maxDuration: 180,
    recommendedDuration: 30,
    resolution: "1080x1920",
    fileSize: "287MB",
    tips: [
      "Hook within first 3 seconds",
      "Use trending sounds",
      "Native vertical format preferred",
      "Keep text overlays minimal"
    ]
  },
  instagram: {
    name: "Instagram Reels",
    aspectRatio: "9:16",
    maxDuration: 90,
    recommendedDuration: 30,
    resolution: "1080x1920",
    fileSize: "650MB",
    tips: [
      "Story-driven content performs best",
      "Use Instagram's native features",
      "Add captions for silent viewing",
      "Post when your audience is active"
    ]
  },
  youtube: {
    name: "YouTube Shorts",
    aspectRatio: "9:16",
    maxDuration: 60,
    recommendedDuration: 30,
    resolution: "1080x1920",
    fileSize: "1GB",
    tips: [
      "#Shorts in title helps discovery",
      "Clear thumbnail matters",
      "End with a call-to-action",
      "Cross-promote from long-form content"
    ]
  }
};

export function SocialMediaPreview({ videoId, videoUrl, title, canvasMethod }: SocialMediaPreviewProps) {
  const [selectedPlatform, setSelectedPlatform] = useState("tiktok");
  const [isMuted, setIsMuted] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [videoQuality, setVideoQuality] = useState([80]);
  const [autoCaption, setAutoCaption] = useState(true);
  const [optimizeHook, setOptimizeHook] = useState(true);

  const currentPlatform = platformSpecs[selectedPlatform];

  const handleOptimize = () => {
    // This would trigger the optimization process
    console.log("Optimizing for", selectedPlatform);
  };

  return (
    <div className="space-y-6">
      <Card className="border-sage-200 dark:border-sage-700">
        <CardHeader>
          <CardTitle className="text-forest-800 dark:text-forest-100 flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-emerald-600" />
            Social Media Preview & Optimizer
          </CardTitle>
          <CardDescription className="text-sage-600 dark:text-sage-400">
            Preview how your Canvas UGC will appear on different platforms
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Platform Tabs */}
          <Tabs value={selectedPlatform} onValueChange={setSelectedPlatform}>
            <TabsList className="grid w-full grid-cols-3 bg-sage-100 dark:bg-sage-800">
              <TabsTrigger value="tiktok" className="flex items-center gap-2">
                <SiTiktok className="h-4 w-4" />
                TikTok
              </TabsTrigger>
              <TabsTrigger value="instagram" className="flex items-center gap-2">
                <Instagram className="h-4 w-4" />
                Reels
              </TabsTrigger>
              <TabsTrigger value="youtube" className="flex items-center gap-2">
                <Play className="h-4 w-4" />
                Shorts
              </TabsTrigger>
            </TabsList>

            <TabsContent value={selectedPlatform} className="mt-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Preview Section */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-forest-800 dark:text-forest-100">
                      {currentPlatform.name} Preview
                    </h3>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setIsMuted(!isMuted)}
                        className="hover:bg-sage-100 dark:hover:bg-sage-700"
                      >
                        {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setIsFullscreen(!isFullscreen)}
                        className="hover:bg-sage-100 dark:hover:bg-sage-700"
                      >
                        {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  {/* Phone Frame Preview */}
                  <div className="relative mx-auto" style={{ maxWidth: "320px" }}>
                    <div className="relative bg-gray-900 rounded-[2.5rem] p-2 shadow-xl">
                      <div className="absolute top-0 left-1/2 transform -translate-x-1/2 h-6 w-32 bg-gray-900 rounded-b-xl"></div>
                      <div className="relative bg-black rounded-[2rem] overflow-hidden" style={{ aspectRatio: "9/16" }}>
                        <video
                          src={videoUrl}
                          className="w-full h-full object-cover"
                          muted={isMuted}
                          controls={false}
                          autoPlay
                          loop
                        />
                        {/* Platform UI Overlay */}
                        <div className="absolute inset-0 pointer-events-none">
                          {selectedPlatform === "tiktok" && (
                            <div className="absolute right-3 bottom-20 space-y-4">
                              <div className="text-white text-center">
                                <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-full mb-1"></div>
                                <span className="text-xs">12.5K</span>
                              </div>
                              <div className="text-white text-center">
                                <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-full mb-1"></div>
                                <span className="text-xs">892</span>
                              </div>
                              <div className="text-white text-center">
                                <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-full mb-1"></div>
                                <span className="text-xs">Share</span>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Platform Specs */}
                  <div className="bg-sage-50 dark:bg-sage-900 rounded-lg p-4 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-sage-600 dark:text-sage-400">Aspect Ratio:</span>
                      <span className="text-forest-700 dark:text-forest-300 font-medium">{currentPlatform.aspectRatio}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-sage-600 dark:text-sage-400">Max Duration:</span>
                      <span className="text-forest-700 dark:text-forest-300 font-medium">{currentPlatform.maxDuration}s</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-sage-600 dark:text-sage-400">Resolution:</span>
                      <span className="text-forest-700 dark:text-forest-300 font-medium">{currentPlatform.resolution}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-sage-600 dark:text-sage-400">Max File Size:</span>
                      <span className="text-forest-700 dark:text-forest-300 font-medium">{currentPlatform.fileSize}</span>
                    </div>
                  </div>
                </div>

                {/* Optimization Settings */}
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold text-forest-800 dark:text-forest-100 mb-4">
                      Optimization Settings
                    </h3>
                    
                    <div className="space-y-4">
                      {/* Video Quality */}
                      <div className="space-y-2">
                        <Label htmlFor="quality" className="text-forest-700 dark:text-forest-300">
                          Video Quality: {videoQuality[0]}%
                        </Label>
                        <Slider
                          id="quality"
                          min={60}
                          max={100}
                          step={5}
                          value={videoQuality}
                          onValueChange={setVideoQuality}
                          className="[&_[role=slider]]:bg-emerald-600"
                        />
                        <p className="text-xs text-sage-600 dark:text-sage-400">
                          Higher quality = larger file size
                        </p>
                      </div>

                      <Separator className="bg-sage-200 dark:bg-sage-700" />

                      {/* Auto Features */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="captions" className="text-forest-700 dark:text-forest-300">
                              Auto-Generate Captions
                            </Label>
                            <p className="text-xs text-sage-600 dark:text-sage-400">
                              Add subtitles for silent viewing
                            </p>
                          </div>
                          <Switch
                            id="captions"
                            checked={autoCaption}
                            onCheckedChange={setAutoCaption}
                            className="data-[state=checked]:bg-emerald-600"
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="hook" className="text-forest-700 dark:text-forest-300">
                              Optimize First 3 Seconds
                            </Label>
                            <p className="text-xs text-sage-600 dark:text-sage-400">
                              Enhance hook for better retention
                            </p>
                          </div>
                          <Switch
                            id="hook"
                            checked={optimizeHook}
                            onCheckedChange={setOptimizeHook}
                            className="data-[state=checked]:bg-emerald-600"
                          />
                        </div>
                      </div>

                      <Separator className="bg-sage-200 dark:bg-sage-700" />

                      {/* Platform Tips */}
                      <div>
                        <h4 className="text-sm font-semibold text-forest-700 dark:text-forest-300 mb-2">
                          {currentPlatform.name} Best Practices
                        </h4>
                        <div className="space-y-1">
                          {currentPlatform.tips.map((tip, index) => (
                            <div key={index} className="flex items-start gap-2 text-sm">
                              <CheckCircle className="h-4 w-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                              <span className="text-sage-700 dark:text-sage-300">{tip}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Canvas Method Optimization */}
                      <Alert className="border-emerald-200 bg-emerald-50 dark:bg-emerald-900/20 dark:border-emerald-700">
                        <AlertCircle className="h-4 w-4 text-emerald-600" />
                        <AlertDescription className="text-emerald-800 dark:text-emerald-200">
                          <strong>{canvasMethod} Method Tip:</strong> This format works best with 
                          {canvasMethod === "Facetime" && " direct eye contact and personal storytelling"}
                          {canvasMethod === "Lazy Girl" && " relaxed energy and minimal editing"}
                          {canvasMethod === "Tutorial" && " clear step-by-step visuals"}
                          {canvasMethod === "Hot Girl Commentary" && " confident delivery and aesthetic visuals"}
                          {canvasMethod === "FOMO" && " fast pacing and trending sounds"}
                        </AlertDescription>
                      </Alert>

                      {/* Format Optimizer */}
                      <FormatOptimizer 
                        videoId={videoId}
                        platform={selectedPlatform}
                        settings={{
                          quality: videoQuality[0],
                          autoCaption: autoCaption,
                          optimizeHook: optimizeHook
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}