import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { 
  Home, Upload, BarChart3, Settings, LogOut, Leaf, 
  ChevronDown, User, Sparkles, Activity
} from "lucide-react";

export default function Navigation() {
  const { user } = useAuth();
  const [location] = useLocation();
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const getInitials = (firstName?: string, lastName?: string) => {
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase() || "U";
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const navItems = [
    { 
      href: "/", 
      icon: Home, 
      label: "Home",
      gradient: "from-emerald-400 to-teal-500"
    },
    { 
      href: "/upload", 
      icon: Upload, 
      label: "Upload",
      gradient: "from-blue-400 to-cyan-500"
    },
    { 
      href: "/metrics", 
      icon: BarChart3, 
      label: "Metrics",
      gradient: "from-purple-400 to-pink-500"
    },
  ];

  return (
    <>
      {/* Main Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-xl border-b border-gray-200/50 shadow-sm">
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-50/20 via-transparent to-teal-50/20 pointer-events-none"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="flex justify-between h-16">
            {/* Logo */}
            <div className="flex items-center">
              <Link href="/">
                <div className="flex items-center space-x-3 group">
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-xl blur-lg opacity-0 group-hover:opacity-40 transition-opacity duration-300"></div>
                    <div className="relative p-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-xl shadow-lg transform group-hover:rotate-3 transition-transform duration-300">
                      <Leaf className="h-5 w-5 text-white" />
                    </div>
                  </div>
                  <div className="hidden sm:block">
                    <span className="text-xl font-light text-gray-900 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-emerald-600 group-hover:to-teal-600 group-hover:bg-clip-text transition-all duration-300">
                      Canvas <span className="font-medium">UGC</span>
                    </span>
                    <div className="flex items-center gap-2 mt-0.5">
                      <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                      <span className="text-xs text-gray-500">AI-powered</span>
                    </div>
                  </div>
                </div>
              </Link>
            </div>

            {/* Center Navigation */}
            <div className="hidden md:flex items-center space-x-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href;
                return (
                  <Link key={item.href} href={item.href}>
                    <button
                      className={`
                        relative px-4 py-2 rounded-xl font-medium text-sm transition-all duration-300
                        ${isActive 
                          ? 'text-white' 
                          : 'text-gray-600 hover:text-gray-900'
                        }
                      `}
                    >
                      {isActive && (
                        <div className={`absolute inset-0 bg-gradient-to-r ${item.gradient} rounded-xl shadow-lg animate-gradient`}></div>
                      )}
                      <div className="relative flex items-center gap-2">
                        <Icon className="h-4 w-4" />
                        <span>{item.label}</span>
                      </div>
                    </button>
                  </Link>
                );
              })}
            </div>

            {/* Mobile Navigation */}
            <div className="flex md:hidden items-center space-x-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href;
                return (
                  <Link key={item.href} href={item.href}>
                    <button
                      className={`
                        relative p-2.5 rounded-xl transition-all duration-300
                        ${isActive 
                          ? 'text-white shadow-lg' 
                          : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                        }
                      `}
                    >
                      {isActive && (
                        <div className={`absolute inset-0 bg-gradient-to-r ${item.gradient} rounded-xl`}></div>
                      )}
                      <Icon className="h-5 w-5 relative z-10" />
                    </button>
                  </Link>
                );
              })}
            </div>

            {/* Right Section */}
            <div className="flex items-center space-x-3">
              {/* Activity Indicator */}
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-emerald-50 rounded-lg">
                <Activity className="h-4 w-4 text-emerald-600" />
                <span className="text-sm font-medium text-emerald-700">Score: 87</span>
              </div>

              {/* Sparkle Button */}
              <button className="relative p-2 rounded-lg hover:bg-gray-100 transition-colors">
                <Sparkles className="h-5 w-5 text-gray-600" />
                <span className="absolute -top-1 -right-1 h-2 w-2 bg-red-500 rounded-full animate-pulse"></span>
              </button>

              {/* Profile Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                  className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-gray-100 transition-all duration-300 group"
                >
                  <div className="relative">
                    <div className="h-9 w-9 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 flex items-center justify-center text-white font-medium shadow-md group-hover:shadow-lg transition-shadow">
                      {getInitials(user?.firstName, user?.lastName)}
                    </div>
                    <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 bg-green-500 rounded-full border-2 border-white"></div>
                  </div>
                  <ChevronDown className={`h-4 w-4 text-gray-500 transition-transform duration-300 ${isProfileOpen ? 'rotate-180' : ''}`} />
                </button>

                {/* Dropdown Menu */}
                {isProfileOpen && (
                  <>
                    <div 
                      className="fixed inset-0 z-40" 
                      onClick={() => setIsProfileOpen(false)}
                    ></div>
                    <div className="absolute right-0 mt-2 w-72 bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-200/50 overflow-hidden z-50 animate-fade-in">
                      {/* Profile Header */}
                      <div className="p-4 bg-gradient-to-r from-emerald-50 to-teal-50 border-b border-gray-200/50">
                        <div className="flex items-center gap-3">
                          <div className="h-12 w-12 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 flex items-center justify-center text-white font-medium text-lg shadow-lg">
                            {getInitials(user?.firstName, user?.lastName)}
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{user?.firstName || ''} {user?.lastName || ''}</p>
                            <p className="text-sm text-gray-500">Content Creator</p>
                          </div>
                        </div>
                        <p className="text-xs text-gray-500 mt-2">{user?.email || 'No email available'}</p>
                      </div>

                      {/* Menu Items */}
                      <div className="p-2">
                        <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors group">
                          <User className="h-4 w-4 text-gray-500 group-hover:text-emerald-600 transition-colors" />
                          <span className="text-sm text-gray-700 group-hover:text-gray-900">View Profile</span>
                        </button>
                        <Link href="/settings">
                          <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors group">
                            <Settings className="h-4 w-4 text-gray-500 group-hover:text-emerald-600 transition-colors" />
                            <span className="text-sm text-gray-700 group-hover:text-gray-900">Settings</span>
                          </button>
                        </Link>
                      </div>

                      {/* Logout */}
                      <div className="p-2 border-t border-gray-200/50">
                        <button 
                          onClick={handleLogout}
                          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-red-50 transition-colors group"
                        >
                          <LogOut className="h-4 w-4 text-gray-500 group-hover:text-red-600 transition-colors" />
                          <span className="text-sm text-gray-700 group-hover:text-red-600">Sign Out</span>
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Spacer for fixed nav */}
      <div className="h-16"></div>
    </>
  );
}
