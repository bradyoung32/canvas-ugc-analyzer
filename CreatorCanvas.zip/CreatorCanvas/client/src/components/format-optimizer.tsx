import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Download, Loader2, CheckCircle2, AlertCircle } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface FormatOptimizerProps {
  videoId: number;
  platform: string;
  settings: {
    quality: number;
    autoCaption: boolean;
    optimizeHook: boolean;
  };
}

export function FormatOptimizer({ videoId, platform, settings }: FormatOptimizerProps) {
  const { toast } = useToast();
  const [optimizationProgress, setOptimizationProgress] = useState(0);
  const [optimizedVideoUrl, setOptimizedVideoUrl] = useState<string | null>(null);

  const optimizeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest(`/api/videos/${videoId}/optimize`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          platform,
          settings
        })
      });
      return response;
    },
    onSuccess: (data) => {
      setOptimizedVideoUrl(data.optimizedUrl);
      toast({
        title: "Optimization Complete",
        description: `Your video has been optimized for ${platform}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Optimization Failed",
        description: "There was an error optimizing your video. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Simulate progress updates
  const handleOptimize = () => {
    setOptimizationProgress(0);
    optimizeMutation.mutate();
    
    // Simulate progress
    const interval = setInterval(() => {
      setOptimizationProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + 10;
      });
    }, 500);
  };

  if (optimizeMutation.isPending) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <Loader2 className="h-5 w-5 animate-spin text-emerald-600" />
          <span className="text-forest-700 dark:text-forest-300">Optimizing video for {platform}...</span>
        </div>
        <Progress value={optimizationProgress} className="h-2" />
        <div className="text-sm text-sage-600 dark:text-sage-400">
          {optimizationProgress < 30 && "Analyzing video content..."}
          {optimizationProgress >= 30 && optimizationProgress < 60 && "Applying platform-specific optimizations..."}
          {optimizationProgress >= 60 && optimizationProgress < 90 && "Finalizing export..."}
          {optimizationProgress >= 90 && "Almost done..."}
        </div>
      </div>
    );
  }

  if (optimizedVideoUrl) {
    return (
      <div className="space-y-4">
        <Alert className="border-emerald-200 bg-emerald-50 dark:bg-emerald-900/20 dark:border-emerald-700">
          <CheckCircle2 className="h-4 w-4 text-emerald-600" />
          <AlertDescription className="text-emerald-800 dark:text-emerald-200">
            Your video has been optimized for {platform} successfully!
          </AlertDescription>
        </Alert>
        
        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-forest-700 dark:text-forest-300">Optimizations Applied:</h4>
          <ul className="space-y-1 text-sm text-sage-700 dark:text-sage-300">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-3 w-3 text-emerald-600" />
              Video quality adjusted to {settings.quality}%
            </li>
            {settings.autoCaption && (
              <li className="flex items-center gap-2">
                <CheckCircle2 className="h-3 w-3 text-emerald-600" />
                Auto-generated captions added
              </li>
            )}
            {settings.optimizeHook && (
              <li className="flex items-center gap-2">
                <CheckCircle2 className="h-3 w-3 text-emerald-600" />
                First 3 seconds optimized for engagement
              </li>
            )}
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-3 w-3 text-emerald-600" />
              Platform-specific format requirements met
            </li>
          </ul>
        </div>

        <Button
          className="w-full bg-gradient-to-r from-emerald-600 to-forest-600 hover:from-emerald-700 hover:to-forest-700 text-white"
          onClick={() => window.open(optimizedVideoUrl, '_blank')}
        >
          <Download className="mr-2 h-4 w-4" />
          Download Optimized Video
        </Button>
      </div>
    );
  }

  return (
    <Button
      onClick={handleOptimize}
      disabled={optimizeMutation.isPending}
      className="w-full bg-gradient-to-r from-emerald-600 to-forest-600 hover:from-emerald-700 hover:to-forest-700 text-white"
    >
      Start Optimization
    </Button>
  );
}