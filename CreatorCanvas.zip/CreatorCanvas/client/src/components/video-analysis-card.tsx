import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Heart, Target, Zap, Shield, Flame, Lightbulb, MessageSquare, Sparkles, BookOpen, CheckCircle } from "lucide-react";
import ScoreRing from "./score-ring";

interface VideoAnalysisCardProps {
  analysis: {
    overallScore: number;
    emotionScore: number;
    convincabilityScore: number;
    persuasionScore: number;
    trustScore: number;
    enthusiasmScore: number;
    aiFeedback: string;
    macAnalysis?: {
      greeting: string;
      methodAssessment: string;
      strengths: string[];
      improvements: string[];
      specificTips: string[];
      encouragement: string;
    };
  };
}

export default function VideoAnalysisCard({ analysis }: VideoAnalysisCardProps) {
  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 80) return "text-blue-600";
    if (score >= 70) return "text-yellow-600";
    return "text-red-600";
  };

  const getPerformanceLabel = (score: number) => {
    if (score >= 90) return "Excellent Performance";
    if (score >= 80) return "Good Performance";
    if (score >= 70) return "Average Performance";
    return "Needs Improvement";
  };

  const getProgressColor = (score: number) => {
    if (score >= 90) return "bg-green-500";
    if (score >= 80) return "bg-blue-500";
    if (score >= 70) return "bg-yellow-500";
    return "bg-red-500";
  };

  const scoreItems = [
    {
      icon: Heart,
      label: "Emotion",
      score: analysis.emotionScore,
      color: "text-red-500",
      bgColor: "bg-red-500",
    },
    {
      icon: Target,
      label: "Convincability",
      score: analysis.convincabilityScore,
      color: "text-blue-500",
      bgColor: "bg-blue-500",
    },
    {
      icon: Zap,
      label: "Persuasion",
      score: analysis.persuasionScore,
      color: "text-purple-500",
      bgColor: "bg-purple-500",
    },
    {
      icon: Shield,
      label: "Trust",
      score: analysis.trustScore,
      color: "text-green-500",
      bgColor: "bg-green-500",
    },
    {
      icon: Flame,
      label: "Enthusiasm",
      score: analysis.enthusiasmScore,
      color: "text-orange-500",
      bgColor: "bg-orange-500",
    },
  ];

  return (
    <Card className="card-shadow border-0 bg-card/90 backdrop-blur">
      <CardHeader>
        <CardTitle className="text-primary">AI Analysis Results</CardTitle>
      </CardHeader>
      <CardContent>
        {/* Overall Score */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <ScoreRing score={analysis.overallScore} size={128} />
          </div>
          <h4 className="text-lg font-light text-primary">Canvas UGC Score</h4>
          <p className={`font-medium ${getScoreColor(analysis.overallScore)}`}>
            {getPerformanceLabel(analysis.overallScore)}
          </p>
        </div>

        {/* Detailed Scores */}
        <div className="space-y-4 mb-6">
          {scoreItems.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <div
                key={index}
                className="flex items-center justify-between p-4 bg-muted/30 rounded-xl"
              >
                <div className="flex items-center">
                  <IconComponent className={`${item.color} mr-3 h-5 w-5`} />
                  <span className="font-medium text-primary">{item.label}</span>
                </div>
                <div className="flex items-center">
                  <div className="w-24 bg-muted rounded-full h-2 mr-3">
                    <div
                      className={`${item.bgColor} h-2 rounded-full transition-all duration-500`}
                      style={{ width: `${Math.min(item.score, 100)}%` }}
                    />
                  </div>
                  <span className="font-semibold min-w-[2rem] text-right text-primary">
                    {item.score}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* AI Feedback */}
        {analysis.aiFeedback && (
          <Alert className="border-0 gradient-cream mb-6">
            <Lightbulb className="h-4 w-4 text-primary" />
            <AlertDescription>
              <strong className="text-primary">AI Feedback:</strong>
              <span className="text-muted-foreground ml-1">{analysis.aiFeedback}</span>
            </AlertDescription>
          </Alert>
        )}

        {/* Mac's Personalized Analysis */}
        {analysis.macAnalysis && (
          <div className="space-y-6">
            <div className="border-t pt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-emerald-600" />
                Mac's Personal Coaching
              </h3>
              
              {/* Greeting */}
              <Alert className="border-0 gradient-sage text-white mb-4">
                <Sparkles className="h-4 w-4 text-white" />
                <AlertDescription className="text-white">
                  {analysis.macAnalysis.greeting}
                </AlertDescription>
              </Alert>

              {/* Method Assessment */}
              <div className="mb-4 p-4 bg-muted/30 rounded-xl">
                <h4 className="font-medium text-primary mb-2">Method Execution</h4>
                <p className="text-muted-foreground">{analysis.macAnalysis.methodAssessment}</p>
              </div>

              {/* Strengths */}
              <div className="mb-4">
                <h4 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  What You Did Well
                </h4>
                <ul className="space-y-2">
                  {analysis.macAnalysis.strengths.map((strength, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-green-600 mr-2">•</span>
                      <span className="text-gray-700">{strength}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Areas for Improvement */}
              <div className="mb-4">
                <h4 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
                  <Target className="h-4 w-4 text-amber-600" />
                  Areas to Work On
                </h4>
                <ul className="space-y-2">
                  {analysis.macAnalysis.improvements.map((improvement, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-amber-600 mr-2">•</span>
                      <span className="text-gray-700">{improvement}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Specific Tips */}
              <div className="mb-4">
                <h4 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-blue-600" />
                  Actionable Tips for Your Next Video
                </h4>
                <ul className="space-y-2">
                  {analysis.macAnalysis.specificTips.map((tip, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-blue-600 mr-2">{index + 1}.</span>
                      <span className="text-gray-700">{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Encouragement */}
              <Alert className="border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
                <Sparkles className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-gray-800 font-medium">
                  {analysis.macAnalysis.encouragement}
                </AlertDescription>
              </Alert>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
