import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import Upload from "@/pages/upload";
import Metrics from "@/pages/metrics";
import MetricsDebug from "@/pages/metrics-debug";
import VideoDetail from "@/pages/video-detail";
import Settings from "@/pages/settings";
import Navigation from "@/components/navigation";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <div className="min-h-screen">
      {isAuthenticated && !isLoading && <Navigation />}
      <Switch>
        {isLoading || !isAuthenticated ? (
          <>
            <Route path="/" component={Landing} />
            <Route path="/landing" component={Landing} />
            <Route path="/upload" component={Landing} />
            <Route path="/metrics" component={Landing} />
            <Route path="/settings" component={Landing} />
            <Route component={Landing} />
          </>
        ) : (
          <>
            <Route path="/" component={Home} />
            <Route path="/upload" component={Upload} />
            <Route path="/metrics" component={Metrics} />
            <Route path="/metrics-debug" component={MetricsDebug} />
            <Route path="/video/:id" component={VideoDetail} />
            <Route path="/settings" component={Settings} />
            <Route component={NotFound} />
          </>
        )}
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
