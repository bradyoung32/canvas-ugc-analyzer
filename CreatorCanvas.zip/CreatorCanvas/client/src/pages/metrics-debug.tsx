import { useAuth } from "@/hooks/useAuth";

export default function MetricsDebug() {
  const { user, isAuthenticated, isLoading } = useAuth();
  
  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-4">Metrics Debug Page</h1>
        
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-2">Authentication Status</h2>
          <pre className="bg-gray-100 p-4 rounded">
            {JSON.stringify({
              isLoading,
              isAuthenticated,
              userExists: !!user,
              user: user ? {
                id: (user as any).id,
                email: (user as any).email,
                firstName: (user as any).firstName,
                lastName: (user as any).lastName
              } : null
            }, null, 2)}
          </pre>
        </div>
        
        <div className="mt-4 bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-2">Page Info</h2>
          <p>Current URL: {window.location.pathname}</p>
          <p>Page Component: MetricsDebug</p>
          <p>Time: {new Date().toISOString()}</p>
        </div>
      </div>
    </div>
  );
}