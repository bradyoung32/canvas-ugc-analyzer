import { useState, useEffect } from "react";
import { 
  Leaf, Shield, Key, UserPlus, ArrowRight, LogIn
} from "lucide-react";

export default function Landing() {
  const [showAccessCode, setShowAccessCode] = useState(false);
  const [accessCode, setAccessCode] = useState('');
  const [scrollY, setScrollY] = useState(0);
  
  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleGetStarted = () => {
    setShowAccessCode(true);
  };

  const handleAccessCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (accessCode) {
      // Since we're using Replit Auth now, redirect to login
      window.location.href = "/api/login";
    }
  };

  return (
    <div className="min-h-[90vh] bg-gradient-to-br from-green-50 via-emerald-50/30 to-teal-50 overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div 
          className="absolute -top-20 -right-20 w-64 h-64 bg-gradient-to-br from-emerald-200/20 to-teal-200/20 rounded-full blur-2xl"
          style={{ transform: `translateY(${scrollY * 0.2}px)` }}
        ></div>
        <div 
          className="absolute -bottom-20 -left-20 w-64 h-64 bg-gradient-to-br from-green-200/20 to-emerald-200/20 rounded-full blur-2xl"
          style={{ transform: `translateY(${-scrollY * 0.2}px)` }}
        ></div>
      </div>

      {/* Hero Section */}
      <div className="relative min-h-[90vh] flex items-center justify-center px-6">
        <div className="text-center relative z-10 max-w-2xl mx-auto pt-8">
          {/* Animated Logo */}
          <div className="inline-flex items-center justify-center mb-6 animate-scale-in">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-3xl blur-xl opacity-50 animate-pulse"></div>
              <div className="relative p-5 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl shadow-2xl transform hover:rotate-3 transition-transform duration-300">
                <Leaf className="h-16 w-16 text-white" />
              </div>
            </div>
          </div>
          
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-light mb-3 text-gray-900 animate-fade-in-up">
            Canvas <span className="font-medium bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">UGC</span>
          </h1>
          
          <p className="text-lg text-gray-600 mb-2 font-light animate-fade-in-up" style={{animationDelay: '0.2s'}}>
            AI-powered content analysis platform
          </p>

          <div className="flex items-center justify-center gap-2 mb-6 animate-fade-in-up" style={{animationDelay: '0.3s'}}>
            <Shield className="h-4 w-4 text-emerald-600" />
            <span className="text-gray-600 text-sm">Private access for authorized team members</span>
          </div>

          {/* Access Code Entry */}
          {!showAccessCode ? (
            <div className="space-y-3 animate-fade-in-up" style={{animationDelay: '0.4s'}}>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <button
                  onClick={handleGetStarted}
                  className="group relative inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-medium rounded-xl shadow-xl hover:shadow-2xl transform hover:-translate-y-1 transition-all duration-300"
                >
                  <Key className="h-4 w-4 group-hover:rotate-12 transition-transform" />
                  <span>Enter Access Code</span>
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={() => window.location.href = "/api/login"}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-white/80 backdrop-blur-sm text-emerald-600 font-medium rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 border border-emerald-200"
                >
                  <LogIn className="h-4 w-4" />
                  <span>Sign In</span>
                </button>
              </div>
              
              <p className="text-sm text-gray-600 mt-8 text-center">
                Need an access code? 
                <a href="#" className="ml-1 text-emerald-600 hover:text-emerald-700 font-medium">
                  Contact your manager
                </a>
              </p>
            </div>
          ) : (
            <form onSubmit={handleAccessCodeSubmit} className="animate-fade-in-up max-w-md mx-auto">
              <div className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-xl">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Enter Your Access Code</h3>
                <div className="space-y-3">
                  <input
                    type="text"
                    value={accessCode}
                    onChange={(e) => setAccessCode(e.target.value)}
                    placeholder="Enter code provided by your manager"
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
                    autoFocus
                  />
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-medium rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300"
                  >
                    <span className="flex items-center justify-center gap-2">
                      <UserPlus className="h-4 w-4" />
                      Create Account
                    </span>
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAccessCode(false)}
                  className="mt-2 text-sm text-gray-500 hover:text-gray-700"
                >
                  ← Back
                </button>
              </div>
              <p className="text-sm text-gray-600 mt-4 text-center">
                Need an access code? 
                <a href="#" className="ml-1 text-emerald-600 hover:text-emerald-700 font-medium">
                  Contact your manager
                </a>
              </p>
            </form>
          )}
        </div>
      </div>

      
    </div>
  );
}
