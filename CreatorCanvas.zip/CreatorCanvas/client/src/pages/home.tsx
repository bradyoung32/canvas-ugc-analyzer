import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Video, Upload, BarChart3, TrendingUp, Trophy, Leaf, 
  MessageCircle, Target, Sparkles, Play, Clock, 
  ChevronRight, Activity, Star, Zap, ArrowUpRight,
  Film, Award, Flame
} from "lucide-react";

export default function Home() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);
  const [timeOfDay, setTimeOfDay] = useState('');
  
  const { data: stats } = useQuery({
    queryKey: ["/api/metrics/stats"],
    enabled: !!user,
  });

  const { data: recentAnalyses } = useQuery({
    queryKey: ["/api/analyses"],
    enabled: !!user,
  });

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) setTimeOfDay('Morning');
    else if (hour < 17) setTimeOfDay('Afternoon');
    else setTimeOfDay('Evening');
  }, []);

  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
        <div className="relative">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
          <Leaf className="absolute inset-0 m-auto h-6 w-6 text-emerald-600 animate-pulse" />
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  // Calculate derived stats
  const todayUploads = recentAnalyses?.filter((item: any) => {
    const today = new Date().toDateString();
    return new Date(item.videos?.createdAt).toDateString() === today;
  })?.length || 0;

  const weekStats = recentAnalyses?.filter((item: any) => {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return new Date(item.videos?.createdAt) > weekAgo;
  }) || [];

  const avgWeekScore = weekStats.length > 0 
    ? Math.round(weekStats.reduce((acc: number, item: any) => acc + (item.video_analyses?.overallScore || 0), 0) / weekStats.length)
    : 0;

  const scoreTrend = avgWeekScore > (stats?.avgScore || 0) ? `+${avgWeekScore - (stats?.avgScore || 0)}%` : "0%";
  
  // Calculate streak (consecutive days with uploads)
  const streakDays = 5; // This would need backend calculation
  const totalStars = Math.floor((stats?.totalVideos || 0) * 2.2); // Example calculation
  const hoursCreated = Math.floor((stats?.totalVideos || 0) * 0.6); // Example calculation

  const actionCards = [
    {
      href: "/upload",
      icon: Upload,
      gradient: "from-emerald-400 to-teal-500",
      title: "Upload Video",
      description: "Analyze new content",
      metric: todayUploads,
      metricLabel: "today"
    },
    {
      href: "/metrics",
      icon: BarChart3,
      gradient: "from-teal-400 to-cyan-500",
      title: "Performance",
      description: "View analytics",
      metric: `${Math.round(stats?.avgScore || 0)}%`,
      metricLabel: "avg score"
    },
    {
      href: "/settings",
      icon: Leaf,
      gradient: "from-green-400 to-emerald-500",
      title: "Profile",
      description: "Manage settings",
      metric: "92%",
      metricLabel: "complete"
    }
  ];

  const statCards = [
    {
      label: "Total Videos",
      value: stats?.totalVideos || 0,
      icon: Video,
      gradient: "from-purple-400 to-pink-500",
      trend: "+12%",
      sparkline: [40, 45, 42, 48, 52, 49, 55]
    },
    {
      label: "Avg Score",
      value: Math.round(stats?.avgScore || 0),
      icon: TrendingUp,
      gradient: "from-blue-400 to-indigo-500",
      trend: scoreTrend,
      sparkline: [60, 62, 65, 63, 68, 70, 72]
    },
    {
      label: "Best Score",
      value: stats?.bestScore || 0,
      icon: Trophy,
      gradient: "from-yellow-400 to-orange-500",
      trend: "Peak",
      sparkline: [70, 72, 75, 80, 78, 85, 92]
    },
    {
      label: "This Week",
      value: stats?.thisWeekCount || 0,
      icon: Activity,
      gradient: "from-green-400 to-teal-500",
      trend: "+23%",
      sparkline: [3, 5, 4, 7, 6, 8, 9]
    }
  ];

  const tips = [
    { 
      icon: Sparkles, 
      title: "Hook Fast", 
      text: "Capture attention in the first 1.5 seconds with a compelling question or visual" 
    },
    { 
      icon: Film, 
      title: "Facetime Method", 
      text: "Record like you're talking to a friend for authentic, engaging content" 
    },
    { 
      icon: Award, 
      title: "Story Arc", 
      text: "Build tension, deliver value, and end with a clear call-to-action" 
    }
  ];

  const generateSparklinePath = (data: number[]) => {
    const width = 100;
    const height = 30;
    const max = Math.max(...data);
    const min = Math.min(...data);
    const range = max - min || 1;
    
    const points = data.map((value, index) => {
      const x = (index / (data.length - 1)) * width;
      const y = height - ((value - min) / range) * height;
      return `${x},${y}`;
    });
    
    return `M ${points.join(' L ')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50/50 to-teal-50 relative overflow-hidden pt-8">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-emerald-200/20 to-teal-200/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-green-200/20 to-emerald-200/20 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
      </div>

      <div className="max-w-7xl mx-auto p-6 pt-8 relative z-10">
        {/* Enhanced Welcome Section */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-100 to-teal-100 rounded-full mb-4">
            <Sparkles className="h-4 w-4 text-emerald-600" />
            <span className="text-sm font-medium text-emerald-700">Good {timeOfDay}!</span>
          </div>
          <h1 className="text-4xl font-light text-gray-900 mb-2">
            Welcome back, <span className="font-medium bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">{user.firstName}</span>
          </h1>
          <p className="text-lg text-gray-600 mb-4">
            Your creative momentum is building
          </p>
          
          {/* Quick insights bar */}
          <div className="flex items-center justify-center gap-8 text-sm">
            <div className="flex items-center gap-2">
              <Flame className="h-4 w-4 text-orange-500" />
              <span className="text-gray-600">
                <span className="font-semibold text-gray-900">{streakDays}</span> day streak
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="h-4 w-4 text-yellow-500" />
              <span className="text-gray-600">
                <span className="font-semibold text-gray-900">{totalStars}</span> stars earned
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-blue-500" />
              <span className="text-gray-600">
                <span className="font-semibold text-gray-900">{hoursCreated}</span> hours created
              </span>
            </div>
          </div>
        </div>

        {/* Enhanced Action Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {actionCards.map((card, index) => {
            const Icon = card.icon;
            return (
              <Link key={index} href={card.href}>
                <div 
                  className="relative overflow-hidden border-0 bg-white/80 backdrop-blur-sm shadow-lg hover:shadow-2xl transition-all duration-500 cursor-pointer group transform hover:-translate-y-1 rounded-xl"
                  onMouseEnter={() => setHoveredCard(index)}
                  onMouseLeave={() => setHoveredCard(null)}
                >
                  <div className={`absolute inset-0 bg-gradient-to-r ${card.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}></div>
                  
                  <div className="p-8 relative">
                    <div className="flex items-start justify-between mb-6">
                      <div className={`p-4 rounded-2xl bg-gradient-to-r ${card.gradient} shadow-lg transform group-hover:scale-110 group-hover:rotate-3 transition-all duration-500`}>
                        <Icon className="h-8 w-8 text-white" />
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-semibold text-gray-900">{card.metric}</p>
                        <p className="text-xs text-gray-500 uppercase tracking-wider">{card.metricLabel}</p>
                      </div>
                    </div>
                    
                    <h3 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-emerald-600 group-hover:to-teal-600 transition-all duration-300">
                      {card.title}
                    </h3>
                    <p className="text-gray-600 mb-4">{card.description}</p>
                    
                    <div className="flex items-center text-emerald-600 font-medium group-hover:gap-2 transition-all duration-300">
                      <span>Get started</span>
                      <ChevronRight className={`h-4 w-4 transition-all duration-300 ${hoveredCard === index ? 'translate-x-1' : ''}`} />
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>

        {/* Enhanced Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {statCards.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="relative overflow-hidden border-0 bg-white/80 backdrop-blur-sm shadow-md hover:shadow-xl transition-all duration-300 group rounded-xl">
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                      <p className="text-3xl font-light text-gray-900">
                        {stat.value}
                      </p>
                    </div>
                    <div className={`p-2 rounded-xl bg-gradient-to-r ${stat.gradient} opacity-90 group-hover:scale-110 transition-transform duration-300`}>
                      <Icon className="h-5 w-5 text-white" />
                    </div>
                  </div>
                  
                  <div className="flex items-end justify-between">
                    <div className="flex items-center gap-1">
                      <ArrowUpRight className="h-3 w-3 text-emerald-600" />
                      <span className="text-xs font-medium text-emerald-600">{stat.trend}</span>
                    </div>
                    
                    <svg className="w-20 h-8" viewBox="0 0 100 30">
                      <path
                        d={generateSparklinePath(stat.sparkline)}
                        fill="none"
                        stroke="url(#gradient)"
                        strokeWidth="2"
                        className="opacity-60"
                      />
                      <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" className="text-emerald-400" stopColor="currentColor" />
                          <stop offset="100%" className="text-teal-400" stopColor="currentColor" />
                        </linearGradient>
                      </defs>
                    </svg>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Recent Activity Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-12">
          <div className="lg:col-span-2 border-0 bg-white/80 backdrop-blur-sm shadow-lg rounded-xl">
            <div className="p-6 pb-4">
              <h3 className="flex items-center justify-between text-lg font-semibold">
                <span className="flex items-center gap-2">
                  <Play className="h-5 w-5 text-emerald-600" />
                  Recent Videos
                </span>
                <Link href="/metrics">
                  <button className="text-emerald-600 hover:text-emerald-700 text-sm font-medium flex items-center gap-1 hover:gap-2 transition-all">
                    View all
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </Link>
              </h3>
            </div>
            <div className="px-6 pb-6 space-y-3">
              {recentAnalyses && recentAnalyses.length > 0 ? (
                recentAnalyses.slice(0, 3).map((item: any, index: number) => (
                  <Link key={index} href={`/video/${item.videos?.id || item.video_analyses?.videoId}`}>
                    <div className="flex items-center gap-4 p-3 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer group">
                      <div className="relative w-20 h-14 bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg overflow-hidden">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Play className="h-6 w-6 text-white/80 group-hover:scale-110 transition-transform" />
                        </div>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{item.videos?.title}</h4>
                        <p className="text-sm text-gray-600">
                          Score: {item.video_analyses?.overallScore || "--"}% • {new Date(item.videos?.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-700">
                        {item.video_analyses ? "Analyzed" : "Processing"}
                      </span>
                    </div>
                  </Link>
                ))
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <Video className="mx-auto h-8 w-8 mb-2" />
                  <p>No videos uploaded yet</p>
                  <p className="text-sm">Start creating to see your recent content here</p>
                </div>
              )}
            </div>
          </div>

          {/* Tips Card */}
          <div className="border-0 bg-gradient-to-br from-emerald-50 to-teal-50 shadow-lg rounded-xl">
            <div className="p-6">
              <h3 className="flex items-center gap-2 text-emerald-800 text-lg font-semibold mb-4">
                <Target className="h-5 w-5" />
                Pro Tips
              </h3>
              <div className="space-y-4">
                {tips.map((tip, index) => {
                  const Icon = tip.icon;
                  return (
                    <div key={index} className="group cursor-pointer">
                      <div className="flex gap-3">
                        <div className="p-2 rounded-lg bg-white/80 group-hover:bg-white transition-colors">
                          <Icon className="h-4 w-4 text-emerald-600" />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900 mb-1">{tip.title}</h4>
                          <p className="text-sm text-gray-600 leading-relaxed">{tip.text}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Achievement Banner */}
        <div className="border-0 bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-xl overflow-hidden relative rounded-xl">
          <div className="absolute right-0 top-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 blur-2xl"></div>
          <div className="p-8 relative">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <h3 className="text-2xl font-semibold mb-2 flex items-center gap-2">
                  <Zap className="h-6 w-6" />
                  You're on fire!
                </h3>
                <p className="text-emerald-100 text-lg">
                  Your content quality has improved by 23% this month. Keep up the amazing work!
                </p>
              </div>
              <Link href="/metrics">
                <button className="bg-white text-emerald-600 hover:bg-emerald-50 shadow-lg px-6 py-3 rounded-lg font-medium flex items-center gap-2 transition-colors">
                  View Achievements
                  <Star className="h-4 w-4" />
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
