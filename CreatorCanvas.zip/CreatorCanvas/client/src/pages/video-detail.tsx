import { useEffect, useState } from "react";
import { useRoute, Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import VideoAnalysisCard from "@/components/video-analysis-card";
import { SocialMediaPreview } from "@/components/social-media-preview";
import { ArrowLeft, Video, Calendar, Clock, Sparkles, Share2 } from "lucide-react";
import { format } from "date-fns";

export default function VideoDetail() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [match, params] = useRoute("/video/:id");
  const videoId = params?.id;

  const { data: videoData, isLoading: videoLoading } = useQuery({
    queryKey: [`/api/videos/${videoId}`],
    enabled: !!videoId && !!user,
  });

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  if (authLoading || videoLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-green-50 to-emerald-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (!user || !videoData) {
    return null;
  }

  const { video, analysis } = videoData;

  const getMethodColor = (method: string) => {
    const colors: Record<string, string> = {
      Facetime: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
      "Lazy Girl": "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
      Tutorial: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
      "Hot Girl Commentary": "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200",
      FOMO: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
    };
    return colors[method] || "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      <div className="max-w-7xl mx-auto p-6 pt-24">
        {/* Header */}
        <div className="mb-6">
          <Link href="/metrics">
            <Button variant="ghost" className="mb-4 hover:bg-sage-100 dark:hover:bg-sage-700">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Metrics
            </Button>
          </Link>
          
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-forest-800 dark:text-forest-100 mb-2">
                {video.title}
              </h1>
              <div className="flex items-center gap-4 text-sm text-sage-600 dark:text-sage-400">
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  {format(new Date(video.createdAt), "MMM dd, yyyy")}
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {format(new Date(video.createdAt), "h:mm a")}
                </div>
                <Badge className={getMethodColor(video.canvasMethod)}>
                  {video.canvasMethod}
                </Badge>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" className="border-sage-300 hover:bg-sage-100 dark:border-sage-600 dark:hover:bg-sage-700">
                <Share2 className="mr-2 h-4 w-4" />
                Share Results
              </Button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="analysis" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-sage-100 dark:bg-sage-800">
            <TabsTrigger value="analysis">Analysis</TabsTrigger>
            <TabsTrigger value="preview">Social Preview</TabsTrigger>
            <TabsTrigger value="video">Original Video</TabsTrigger>
          </TabsList>

          <TabsContent value="analysis" className="space-y-6">
            {analysis ? (
              <VideoAnalysisCard analysis={analysis} />
            ) : (
              <Card className="border-amber-200 bg-amber-50 dark:bg-amber-900/20 dark:border-amber-700">
                <CardContent className="pt-6">
                  <p className="text-amber-800 dark:text-amber-200">
                    Analysis is still processing. Please check back in a moment.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="preview">
            <SocialMediaPreview 
              videoId={video.id}
              videoUrl={video.fileUrl} 
              title={video.title}
              canvasMethod={video.canvasMethod}
            />
          </TabsContent>

          <TabsContent value="video">
            <Card className="border-sage-200 dark:border-sage-700">
              <CardHeader>
                <CardTitle className="text-forest-800 dark:text-forest-100 flex items-center gap-2">
                  <Video className="h-5 w-5 text-emerald-600" />
                  Original Video
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-video bg-black rounded-lg overflow-hidden">
                  <video 
                    src={video.fileUrl} 
                    controls 
                    className="w-full h-full"
                    preload="metadata"
                  >
                    Your browser does not support the video tag.
                  </video>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}