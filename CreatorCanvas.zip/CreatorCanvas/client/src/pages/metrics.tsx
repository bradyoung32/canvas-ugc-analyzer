import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { 
  Video, TrendingUp, Trophy, Flame, Play, Target, Heart, 
  Zap, Shield, MessageCircle, Sparkles, ChevronRight,
  Activity, BarChart3
} from "lucide-react";

export default function Metrics() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [selectedPeriod, setSelectedPeriod] = useState("week");

  const { data: stats = {}, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/metrics/stats"],
    retry: false,
    enabled: isAuthenticated,
  });

  const { data: canvasMethods = [], isLoading: methodsLoading } = useQuery({
    queryKey: ["/api/metrics/canvas-methods"],
    retry: false,
    enabled: isAuthenticated,
  });

  const { data: recentAnalyses = [], isLoading: analysesLoading } = useQuery({
    queryKey: ["/api/analyses"],
    retry: false,
    enabled: isAuthenticated,
  });

  // Don't wait for auth loading to render the page
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen pt-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-emerald-600";
    if (score >= 80) return "text-blue-600";
    if (score >= 70) return "text-amber-600";
    return "text-red-600";
  };

  const formatMethod = (method: string) => {
    const methodMap: { [key: string]: string } = {
      "Facetime Method": "Facetime",
      "Lazy Girl Method": "Lazy Girl",
      "Tutorial/How I Did This": "Tutorial",
      "Hot Girl Commentary": "Commentary",
      "FOMO Method": "FOMO"
    };
    return methodMap[method] || method;
  };

  const performanceMetrics = [
    { 
      label: "Emotion", 
      value: (stats as any)?.avgEmotionScore || 0, 
      icon: Heart,
      description: "Emotional connection"
    },
    { 
      label: "Convincability", 
      value: (stats as any)?.avgConvincabilityScore || 0, 
      icon: Target,
      description: "Persuasive impact"
    },
    { 
      label: "Persuasion", 
      value: (stats as any)?.avgPersuasionScore || 0, 
      icon: Zap,
      description: "Influence strength"
    },
    { 
      label: "Trust", 
      value: (stats as any)?.avgTrustScore || 0, 
      icon: Shield,
      description: "Credibility score"
    },
    { 
      label: "Enthusiasm", 
      value: (stats as any)?.avgEnthusiasmScore || 0, 
      icon: Flame,
      description: "Energy level"
    },
    { 
      label: "Overall", 
      value: (stats as any)?.avgScore || 0, 
      icon: Activity,
      description: "Combined score",
      highlight: true
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-light text-gray-900">Performance Metrics</h1>
          <p className="text-gray-500 mt-1">Track your content performance and insights</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Videos</p>
                <p className="text-2xl font-light text-gray-900 mt-1">{(stats as any)?.totalVideos || 0}</p>
              </div>
              <Video className="h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Best Score</p>
                <p className="text-2xl font-light text-gray-900 mt-1">{(stats as any)?.bestScore || "--"}</p>
              </div>
              <Trophy className="h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Improvement</p>
                <p className="text-2xl font-light text-emerald-600 mt-1">+{(stats as any)?.improvement || 0}%</p>
              </div>
              <TrendingUp className="h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">This Week</p>
                <p className="text-2xl font-light text-gray-900 mt-1">{(stats as any)?.thisWeekCount || 0}</p>
              </div>
              <Activity className="h-5 w-5 text-gray-400" />
            </div>
          </div>
        </div>

        {/* Performance Metrics Grid */}
        <div className="bg-white rounded-lg border border-gray-200 p-6 mb-8">
          <h2 className="text-lg font-light text-gray-900 mb-6">Performance Breakdown</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {performanceMetrics.map((metric, index) => {
              const Icon = metric.icon;
              return (
                <div key={index} className={`text-center ${metric.highlight ? 'lg:col-span-1' : ''}`}>
                  <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg mb-3 ${
                    metric.highlight ? 'bg-gray-900' : 'bg-gray-100'
                  }`}>
                    <Icon className={`h-5 w-5 ${metric.highlight ? 'text-white' : 'text-gray-600'}`} />
                  </div>
                  <p className="text-sm text-gray-500 mb-1">{metric.label}</p>
                  <p className={`text-2xl font-light ${metric.highlight ? 'text-gray-900 font-normal' : 'text-gray-700'}`}>
                    {Math.round(metric.value)}
                  </p>
                  <p className="text-xs text-gray-400 mt-1">{metric.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Canvas Methods Performance */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-light text-gray-900">Method Performance</h2>
              <BarChart3 className="h-5 w-5 text-gray-400" />
            </div>
            <div className="space-y-4">
              {methodsLoading ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-900"></div>
                </div>
              ) : canvasMethods && Array.isArray(canvasMethods) && canvasMethods.length > 0 ? (
                canvasMethods.map((method: any, index: number) => (
                  <div key={index}>
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <span className="text-sm text-gray-700">{formatMethod(method.canvasMethod)}</span>
                        <span className="text-xs text-gray-500 ml-2">({method.count || 0} videos)</span>
                      </div>
                      <span className="text-sm font-medium text-gray-900">{Math.round(method.avgScore)}%</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-1.5">
                      <div
                        className="bg-gray-900 h-1.5 rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(method.avgScore, 100)}%` }}
                      />
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <BarChart3 className="mx-auto h-8 w-8 mb-2" />
                  <p>No performance data yet</p>
                  <p className="text-sm">Upload videos to see your Canvas method performance</p>
                </div>
              )}
            </div>
          </div>

          {/* Performance Trend */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-light text-gray-900">Weekly Trend</h2>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedPeriod("week")}
                  className={`px-3 py-1 text-xs rounded-md transition-colors ${
                    selectedPeriod === "week" 
                      ? "bg-gray-900 text-white" 
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  Week
                </button>
                <button
                  onClick={() => setSelectedPeriod("month")}
                  className={`px-3 py-1 text-xs rounded-md transition-colors ${
                    selectedPeriod === "month" 
                      ? "bg-gray-900 text-white" 
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  Month
                </button>
              </div>
            </div>
            <div className="h-48 flex items-end justify-between gap-2">
              {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => (
                <div key={day} className="flex-1 flex flex-col items-center">
                  <div className="w-full bg-gray-200 rounded-t" style={{
                    height: `${Math.random() * 70 + 30}%`,
                    opacity: index === 6 ? 1 : 0.5
                  }}></div>
                  <span className="text-xs text-gray-500 mt-2">{day}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent Videos */}
        <div className="bg-white rounded-lg border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-light text-gray-900">Recent Videos</h2>
              <button className="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1">
                View all
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
          <div className="divide-y divide-gray-200">
            {analysesLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-900"></div>
              </div>
            ) : recentAnalyses && Array.isArray(recentAnalyses) && recentAnalyses.length > 0 ? (
              recentAnalyses.slice(0, 5).map((item: any, index: number) => (
                <div 
                  key={index}
                  className="p-6 hover:bg-gray-50 transition-colors cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                        <Play className="h-4 w-4 text-gray-600" />
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-gray-900">{item.videos?.title || 'Untitled Video'}</h3>
                        <p className="text-sm text-gray-500 mt-0.5">
                          {formatMethod(item.videos?.canvasMethod || 'Unknown Method')} • {" "}
                          {item.videos?.createdAt ? new Date(item.videos.createdAt).toLocaleDateString() : 'Unknown date'}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-xl font-light ${getScoreColor(item.video_analyses?.overallScore || 0)}`}>
                        {item.video_analyses?.overallScore || "--"}
                      </p>
                      <p className="text-xs text-gray-500">Score</p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-gray-500">
                <Video className="mx-auto h-12 w-12 mb-4" />
                <p>No videos uploaded yet</p>
                <p className="text-sm">Start uploading Canvas UGC videos to see your metrics</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
