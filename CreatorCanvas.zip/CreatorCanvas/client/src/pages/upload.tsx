import React, { useState, useCallback } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  Upload, CloudUpload, Brain, Sparkles, Video, 
  ChevronRight, Zap, Film, Target, Award, 
  Activity, TrendingUp, Clock, Star
} from "lucide-react";

export default function UploadPage() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [canvasMethod, setCanvasMethod] = useState("");
  const [dragActive, setDragActive] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [hoveredTip, setHoveredTip] = useState<number | null>(null);

  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch("/api/videos/upload", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(`${response.status}: ${error}`);
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Video Uploaded Successfully",
        description: "Your video is being analyzed. Results will appear shortly.",
      });
      
      // Poll for analysis results
      pollForAnalysis(data.id);
      
      // Reset form
      setSelectedFile(null);
      setTitle("");
      setCanvasMethod("");
      
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload video",
        variant: "destructive",
      });
    },
  });

  const pollForAnalysis = async (videoId: string) => {
    const maxAttempts = 30;
    let attempts = 0;
    
    const poll = async () => {
      if (attempts >= maxAttempts) {
        toast({
          title: "Analysis Timeout",
          description: "Analysis is taking longer than expected. Please check back later.",
          variant: "destructive",
        });
        return;
      }
      
      try {
        const response = await fetch(`/api/videos/${videoId}/analysis`, {
          credentials: "include",
        });
        
        if (response.ok) {
          const analysis = await response.json();
          if (analysis && analysis.overallScore !== undefined) {
            setAnalysisResult(analysis);
            toast({
              title: "Analysis Complete",
              description: `Your video scored ${Math.round(analysis.overallScore)}%!`,
            });
            return;
          }
        }
        
        attempts++;
        setTimeout(poll, 2000);
      } catch (error) {
        console.error("Error polling for analysis:", error);
        attempts++;
        setTimeout(poll, 2000);
      }
    };
    
    poll();
  };

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith("video/")) {
        setSelectedFile(file);
      } else {
        toast({
          title: "Invalid File Type",
          description: "Please select a video file.",
          variant: "destructive",
        });
      }
    }
  }, [toast]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleSubmit = async () => {
    if (!selectedFile || !title || !canvasMethod) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields and select a video file.",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    const formData = new FormData();
    formData.append("video", selectedFile);
    formData.append("title", title);
    formData.append("canvasMethod", canvasMethod);

    uploadMutation.mutate(formData);
    setIsUploading(false);
  };

  const canvasMethods = [
    { value: "Facetime Method", icon: Video, description: "Personal & authentic" },
    { value: "Lazy Girl Method", icon: Sparkles, description: "Effortless & relatable" },
    { value: "Tutorial/How I Did This", icon: Film, description: "Educational & helpful" },
    { value: "Hot Girl Commentary", icon: Zap, description: "Bold & engaging" },
    { value: "FOMO Method", icon: TrendingUp, description: "Urgency & excitement" }
  ];

  const uploadTips = [
    { 
      icon: Clock, 
      title: "Keep it Short", 
      text: "15-60 seconds is the sweet spot for maximum engagement" 
    },
    { 
      icon: Target, 
      title: "Clear Audio", 
      text: "Good sound quality is crucial - viewers will forgive video issues but not audio" 
    },
    { 
      icon: Star, 
      title: "Natural Lighting", 
      text: "Face a window or use ring light for that professional glow" 
    }
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen pt-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50/50 to-teal-50 relative overflow-hidden pt-8">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-emerald-200/20 to-teal-200/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-green-200/20 to-emerald-200/20 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-teal-200/10 to-emerald-200/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
      </div>

      <div className="max-w-6xl mx-auto p-6 pt-8 relative z-10">
        {/* Enhanced Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-100 to-teal-100 rounded-full mb-4">
            <Upload className="h-4 w-4 text-emerald-600" />
            <span className="text-sm font-medium text-emerald-700">Canvas Studio</span>
          </div>
          <h1 className="text-4xl font-light text-gray-900 mb-2">
            Upload Your <span className="font-medium bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">Canvas UGC</span>
          </h1>
          <p className="text-lg text-gray-600">
            Let's analyze your content with AI-powered insights
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Enhanced Upload Section */}
          <div className="space-y-6">
            <div className="rounded-xl border-0 bg-white/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border-b border-emerald-100/50 p-6">
                <h3 className="flex items-center gap-2 text-emerald-800 text-lg font-semibold">
                  <div className="p-2 rounded-lg bg-gradient-to-r from-emerald-400 to-teal-500 shadow">
                    <Upload className="h-5 w-5 text-white" />
                  </div>
                  Video Upload
                </h3>
              </div>
              <div className="p-8">
                <div className="space-y-6">
                  {/* Enhanced File Upload Area */}
                  <div
                    className={`relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300 ${
                      dragActive
                        ? "border-emerald-500 bg-gradient-to-br from-emerald-50 to-teal-50 scale-[1.02]"
                        : selectedFile
                        ? "border-emerald-400 bg-gradient-to-br from-emerald-50/50 to-teal-50/50"
                        : "border-gray-300 hover:border-emerald-400 hover:bg-gradient-to-br hover:from-emerald-50/30 hover:to-teal-50/30"
                    }`}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                  >
                    <div className={`transition-all duration-300 ${dragActive ? 'scale-110' : ''}`}>
                      <CloudUpload className={`mx-auto h-16 w-16 mb-4 transition-colors ${
                        selectedFile ? 'text-emerald-600' : 'text-gray-400'
                      }`} />
                      {selectedFile ? (
                        <div>
                          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-100 rounded-full mb-2">
                            <Video className="h-4 w-4 text-emerald-600" />
                            <span className="text-sm font-medium text-emerald-700">Video Selected</span>
                          </div>
                          <p className="text-lg font-medium text-gray-900 mb-1">
                            {selectedFile.name}
                          </p>
                          <p className="text-sm text-gray-600">
                            {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                          </p>
                        </div>
                      ) : (
                        <div>
                          <p className="text-lg font-light text-gray-700 mb-2">
                            Drop your video here
                          </p>
                          <p className="text-sm text-gray-500">or click to browse</p>
                          <p className="text-xs text-gray-400 mt-2">MP4, MOV, AVI up to 100MB</p>
                        </div>
                      )}
                    </div>
                    <input
                      type="file"
                      accept="video/*"
                      onChange={handleFileSelect}
                      className="hidden"
                      id="video-upload"
                    />
                    <button
                      type="button"
                      className="mt-6 px-4 py-2 border border-emerald-200 text-emerald-700 hover:bg-emerald-50 hover:border-emerald-300 transition-all duration-300 rounded-lg"
                      onClick={() => document.getElementById("video-upload")?.click()}
                    >
                      {selectedFile ? 'Change File' : 'Choose File'}
                    </button>
                  </div>

                  {/* Enhanced Video Details */}
                  <div className="space-y-5">
                    <div className="space-y-2">
                      <label className="text-gray-700 font-medium text-sm">Video Title</label>
                      <input
                        type="text"
                        placeholder="Give your video a catchy title"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-400/20 transition-all"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-gray-700 font-medium text-sm">Canvas Method</label>
                      <select 
                        value={canvasMethod} 
                        onChange={(e) => setCanvasMethod(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-400/20 transition-all"
                      >
                        <option value="">Select your content style</option>
                        {canvasMethods.map((method) => (
                          <option key={method.value} value={method.value}>
                            {method.value} - {method.description}
                          </option>
                        ))}
                      </select>
                    </div>

                    <button
                      onClick={handleSubmit}
                      disabled={isUploading || uploadMutation.isPending}
                      className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      <Brain className="h-4 w-4" />
                      {isUploading || uploadMutation.isPending ? "Uploading..." : "Analyze with AI"}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Upload Tips Card */}
            <div className="rounded-xl border-0 bg-gradient-to-br from-emerald-50 to-teal-50 shadow-lg">
              <div className="p-6">
                <h3 className="flex items-center gap-2 text-emerald-800 text-lg font-semibold mb-4">
                  <Award className="h-5 w-5" />
                  Pro Upload Tips
                </h3>
                <div className="space-y-4">
                  {uploadTips.map((tip, index) => {
                    const Icon = tip.icon;
                    return (
                      <div 
                        key={index} 
                        className="group cursor-pointer"
                        onMouseEnter={() => setHoveredTip(index)}
                        onMouseLeave={() => setHoveredTip(null)}
                      >
                        <div className="flex gap-3">
                          <div className={`p-2 rounded-lg transition-all duration-300 ${
                            hoveredTip === index 
                              ? 'bg-white shadow-md scale-110' 
                              : 'bg-white/60'
                          }`}>
                            <Icon className="h-4 w-4 text-emerald-600" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900 mb-1">{tip.title}</h4>
                            <p className="text-sm text-gray-600 leading-relaxed">{tip.text}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Enhanced Results Section */}
          {analysisResult ? (
            <div className="space-y-6">
              <div className="rounded-xl border-0 bg-white/80 backdrop-blur-sm shadow-lg overflow-hidden">
                <div className="bg-gradient-to-r from-teal-50 to-emerald-50 border-b border-teal-100/50 p-6">
                  <h3 className="flex items-center gap-2 text-teal-800 text-lg font-semibold">
                    <div className="p-2 rounded-lg bg-gradient-to-r from-teal-400 to-emerald-500 shadow">
                      <Brain className="h-5 w-5 text-white" />
                    </div>
                    Analysis Results
                  </h3>
                </div>
                <div className="p-8">
                  <div className="text-center mb-6">
                    <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full text-white text-2xl font-bold mb-4 shadow-lg">
                      {Math.round(analysisResult.overallScore)}%
                    </div>
                    <h4 className="text-xl font-semibold text-gray-900 mb-2">Overall Score</h4>
                    <p className="text-gray-600">Your Canvas UGC performance rating</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="text-center p-4 bg-gradient-to-br from-emerald-50 to-teal-50 rounded-lg">
                      <Activity className="h-6 w-6 mx-auto mb-2 text-emerald-600" />
                      <p className="text-sm text-gray-600 mb-1">Engagement</p>
                      <p className="text-lg font-semibold text-gray-900">{Math.round(analysisResult.engagement || 0)}%</p>
                    </div>
                    <div className="text-center p-4 bg-gradient-to-br from-teal-50 to-emerald-50 rounded-lg">
                      <Star className="h-6 w-6 mx-auto mb-2 text-teal-600" />
                      <p className="text-sm text-gray-600 mb-1">Quality</p>
                      <p className="text-lg font-semibold text-gray-900">{Math.round(analysisResult.quality || 0)}%</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Virality Potential</span>
                      <span className="text-sm font-semibold text-gray-900">{Math.round(analysisResult.virality || 0)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-emerald-400 to-teal-500 h-2 rounded-full transition-all duration-1000"
                        style={{ width: `${analysisResult.virality || 0}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className="mt-6 flex gap-3">
                    <button className="flex-1 py-2 px-4 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-lg hover:from-emerald-600 hover:to-teal-600 transition-all duration-300 flex items-center justify-center gap-2">
                      <ChevronRight className="h-4 w-4" />
                      View Details
                    </button>
                    <button className="py-2 px-4 border border-emerald-200 text-emerald-700 rounded-lg hover:bg-emerald-50 transition-all duration-300">
                      Share
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="rounded-xl border-0 bg-white/80 backdrop-blur-sm shadow-lg overflow-hidden">
                <div className="bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200/50 p-6">
                  <h3 className="flex items-center gap-2 text-gray-800 text-lg font-semibold">
                    <div className="p-2 rounded-lg bg-gradient-to-r from-gray-400 to-gray-500 shadow">
                      <Brain className="h-5 w-5 text-white" />
                    </div>
                    Waiting for Analysis
                  </h3>
                </div>
                <div className="p-8 text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                    <Upload className="h-8 w-8 text-gray-400" />
                  </div>
                  <p className="text-gray-600 mb-4">Upload a video to see AI-powered insights</p>
                  <p className="text-sm text-gray-500">Our Canvas UGC analysis will provide detailed feedback on your content's performance potential</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}