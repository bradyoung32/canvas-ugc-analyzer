import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function Settings() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    contentFocus: "",
    primaryPlatform: "",
    detailedFeedback: true,
    emailNotifications: true,
    weeklyReports: false,
    dataStorage: true,
  });

  useEffect(() => {
    if (user) {
      setFormData({
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        email: user.email || "",
        contentFocus: user.contentFocus || "",
        primaryPlatform: user.primaryPlatform || "",
        detailedFeedback: user.detailedFeedback !== false,
        emailNotifications: user.emailNotifications !== false,
        weeklyReports: user.weeklyReports === true,
        dataStorage: user.dataStorage !== false,
      });
    }
  }, [user]);

  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, isLoading, toast]);

  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("PATCH", "/api/user/settings", data);
    },
    onSuccess: () => {
      toast({
        title: "Settings Updated",
        description: "Your settings have been saved successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Update Failed",
        description: "Failed to update settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      <div className="max-w-4xl mx-auto p-6 pt-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold bg-gradient-to-r from-green-800 to-emerald-600 bg-clip-text text-transparent mb-2">
            Settings
          </h2>
          <p className="text-lg text-gray-700">
            Manage your account preferences and Canvas UGC analysis settings.
          </p>
        </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Profile Settings */}
        <Card className="border-green-200 bg-white">
          <CardHeader>
            <CardTitle className="text-gray-800">Profile Settings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => handleInputChange("firstName", e.target.value)}
                  placeholder="Enter your first name"
                />
              </div>

              <div>
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => handleInputChange("lastName", e.target.value)}
                  placeholder="Enter your last name"
                />
              </div>

              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  placeholder="Enter your email"
                />
              </div>

              <div>
                <Label htmlFor="contentFocus">Content Focus</Label>
                <Select
                  value={formData.contentFocus}
                  onValueChange={(value) => handleInputChange("contentFocus", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your content focus" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Lifestyle & Wellness">Lifestyle & Wellness</SelectItem>
                    <SelectItem value="Business & Entrepreneurship">Business & Entrepreneurship</SelectItem>
                    <SelectItem value="Fashion & Beauty">Fashion & Beauty</SelectItem>
                    <SelectItem value="Technology & Productivity">Technology & Productivity</SelectItem>
                    <SelectItem value="Food & Cooking">Food & Cooking</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="primaryPlatform">Primary Platform</Label>
                <Select
                  value={formData.primaryPlatform}
                  onValueChange={(value) => handleInputChange("primaryPlatform", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your primary platform" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="TikTok">TikTok</SelectItem>
                    <SelectItem value="Instagram Reels">Instagram Reels</SelectItem>
                    <SelectItem value="YouTube Shorts">YouTube Shorts</SelectItem>
                    <SelectItem value="Multiple Platforms">Multiple Platforms</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Analysis Preferences */}
        <Card className="border-teal-200 bg-white">
          <CardHeader>
            <CardTitle className="text-gray-800">Analysis Preferences</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base font-medium">Detailed Feedback</Label>
                  <p className="text-sm text-gray-500">
                    Receive comprehensive AI feedback on your videos
                  </p>
                </div>
                <Switch
                  checked={formData.detailedFeedback}
                  onCheckedChange={(checked) => handleInputChange("detailedFeedback", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base font-medium">Email Notifications</Label>
                  <p className="text-sm text-gray-500">
                    Get notified when your video analysis is complete
                  </p>
                </div>
                <Switch
                  checked={formData.emailNotifications}
                  onCheckedChange={(checked) => handleInputChange("emailNotifications", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base font-medium">Weekly Reports</Label>
                  <p className="text-sm text-gray-500">
                    Receive weekly performance summaries
                  </p>
                </div>
                <Switch
                  checked={formData.weeklyReports}
                  onCheckedChange={(checked) => handleInputChange("weeklyReports", checked)}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Data & Privacy */}
        <Card className="border-green-200 bg-white">
          <CardHeader>
            <CardTitle className="text-gray-800">Data & Privacy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base font-medium">Data Storage</Label>
                  <p className="text-sm text-gray-500">
                    Allow secure storage of video data for learning improvements
                  </p>
                </div>
                <Switch
                  checked={formData.dataStorage}
                  onCheckedChange={(checked) => handleInputChange("dataStorage", checked)}
                />
              </div>

              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>Data Usage:</strong> Your video data is processed using Pinecone for analysis
                  and Lemonfox for transcription. All data is encrypted and used solely for improving
                  your Canvas UGC performance.
                </AlertDescription>
              </Alert>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex justify-end space-x-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => window.location.reload()}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={updateMutation.isPending}
            className="bg-gradient-emerald hover:opacity-90 text-gray-800"
          >
            {updateMutation.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </form>
      </div>
    </div>
  );
}
