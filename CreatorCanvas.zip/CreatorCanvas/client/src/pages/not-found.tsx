export default function NotFound() {
  return null;
}
