import fs from 'fs';
import FormData from 'form-data';

const LEMONFOX_API_URL = 'https://api.lemonfox.ai/v1/transcribe';

export interface TranscriptionResult {
  transcription: string;
  duration: number;
  language: string;
  confidence: number;
}

export async function transcribeVideo(videoPath: string): Promise<TranscriptionResult> {
  try {
    if (!process.env.LEMONFOX_API_KEY) {
      throw new Error('Lemonfox API key not configured');
    }

    // Create form data with video file
    const form = new FormData();
    form.append('file', fs.createReadStream(videoPath));
    form.append('model', 'whisper-large-v3'); // Using best model for accuracy
    form.append('language', 'en'); // English transcription
    form.append('response_format', 'json');

    const response = await fetch(LEMONFOX_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.LEMONFOX_API_KEY}`,
        ...form.getHeaders()
      },
      body: form as any
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Lemonfox API error: ${response.status} - ${error}`);
    }

    const data = await response.json();

    return {
      transcription: data.text || '',
      duration: data.duration || 0,
      language: data.language || 'en',
      confidence: data.confidence || 0
    };
  } catch (error) {
    console.error('Error transcribing video with Lemonfox:', error);
    throw error;
  }
}

// Extract audio from video file (simplified version)
// In production, you'd use ffmpeg or similar tool
export async function extractAudioFromVideo(videoPath: string): Promise<string> {
  // For now, we'll pass the video directly to Lemonfox
  // Most transcription services accept video files directly
  return videoPath;
}