import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertVideoSchema, insertVideoAnalysisSchema, updateUserSettingsSchema } from "@shared/schema";
import multer from 'multer';
import path from 'path';
import { z } from "zod";
import { analyzeVideoContent, generateMockTranscription } from "./openai";
import { transcribeVideo } from "./lemonfox";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  fileFilter: (req, file, cb) => {
    const allowedTypes = /mp4|mov|avi|webm/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only video files are allowed'));
    }
  },
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB limit
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Access code validation
  app.post('/api/auth/validate-code', async (req, res) => {
    try {
      const { code } = req.body;
      if (!code) {
        return res.status(400).json({ message: "Access code is required" });
      }

      const accessCode = await storage.validateAccessCode(code);
      if (!accessCode) {
        return res.status(400).json({ message: "Invalid or already used access code" });
      }

      res.json({ valid: true });
    } catch (error) {
      console.error("Error validating access code:", error);
      res.status(500).json({ message: "Failed to validate access code" });
    }
  });

  // User settings
  app.patch('/api/user/settings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = updateUserSettingsSchema.parse(req.body);
      
      const updatedUser = await storage.updateUserSettings(userId, validatedData);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user settings:", error);
      res.status(500).json({ message: "Failed to update settings" });
    }
  });

  // Video upload
  app.post('/api/videos/upload', isAuthenticated, upload.single('video'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { title, canvasMethod } = req.body;
      
      if (!req.file) {
        return res.status(400).json({ message: "No video file uploaded" });
      }

      const videoData = {
        userId,
        title,
        filename: req.file.originalname,
        fileUrl: req.file.path,
        canvasMethod,
      };

      const validatedData = insertVideoSchema.parse(videoData);
      const video = await storage.createVideo({ ...validatedData, userId });

      // Start AI analysis process
      processVideoAnalysis(video.id, canvasMethod, video.fileUrl);

      res.json(video);
    } catch (error) {
      console.error("Error uploading video:", error);
      res.status(500).json({ message: "Failed to upload video" });
    }
  });

  // Get user videos
  app.get('/api/videos', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const videos = await storage.getUserVideos(userId);
      res.json(videos);
    } catch (error) {
      console.error("Error fetching videos:", error);
      res.status(500).json({ message: "Failed to fetch videos" });
    }
  });

  // Get video analysis
  app.get('/api/videos/:id/analysis', isAuthenticated, async (req: any, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const analysis = await storage.getVideoAnalysis(videoId);
      res.json(analysis);
    } catch (error) {
      console.error("Error fetching video analysis:", error);
      res.status(500).json({ message: "Failed to fetch analysis" });
    }
  });

  // Get user analyses with videos
  app.get('/api/analyses', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const analyses = await storage.getUserAnalyses(userId);
      res.json(analyses);
    } catch (error) {
      console.error("Error fetching analyses:", error);
      res.status(500).json({ message: "Failed to fetch analyses" });
    }
  });

  // Get user metrics
  app.get('/api/metrics/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Get canvas method performance
  app.get('/api/metrics/canvas-methods', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const performance = await storage.getUserCanvasMethodPerformance(userId);
      res.json(performance);
    } catch (error) {
      console.error("Error fetching canvas method performance:", error);
      res.status(500).json({ message: "Failed to fetch performance data" });
    }
  });

  // Get individual video with analysis
  app.get('/api/videos/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const videoId = parseInt(req.params.id);
      
      const video = await storage.getVideo(videoId);
      
      if (!video || video.userId !== userId) {
        return res.status(404).json({ message: "Video not found" });
      }
      
      const analysis = await storage.getVideoAnalysis(videoId);
      
      res.json({ video, analysis });
    } catch (error) {
      console.error("Error fetching video:", error);
      res.status(500).json({ message: "Failed to fetch video" });
    }
  });

  // Optimize video for specific platform
  app.post('/api/videos/:id/optimize', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const videoId = parseInt(req.params.id);
      const { platform, settings } = req.body;
      
      const video = await storage.getVideo(videoId);
      
      if (!video || video.userId !== userId) {
        return res.status(404).json({ message: "Video not found" });
      }
      
      // In a real implementation, this would trigger a video processing job
      // For now, we'll simulate the optimization and return the same URL
      // In production, this would integrate with a video processing service like FFmpeg
      
      console.log(`Optimizing video ${videoId} for ${platform} with settings:`, settings);
      
      // Simulate processing delay
      setTimeout(() => {
        console.log(`Optimization complete for video ${videoId}`);
      }, 2000);
      
      // Return optimized video URL (in production, this would be a new processed file)
      res.json({
        optimizedUrl: video.fileUrl,
        platform,
        optimizations: {
          quality: settings.quality,
          captions: settings.autoCaption,
          hookOptimized: settings.optimizeHook,
          format: platform === 'tiktok' ? 'mp4' : 'mp4',
          resolution: '1080x1920',
          aspectRatio: '9:16'
        }
      });
    } catch (error) {
      console.error("Error optimizing video:", error);
      res.status(500).json({ message: "Failed to optimize video" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// AI analysis function using OpenAI and Lemonfox
async function processVideoAnalysis(videoId: number, canvasMethod: string, videoPath: string) {
  try {
    // Update status to processing
    await storage.updateVideoStatus(videoId, "processing");

    // Process video analysis asynchronously
    setTimeout(async () => {
      try {
        // Get transcription using Lemonfox API or fallback to mock
        let transcription: string;
        
        if (process.env.LEMONFOX_API_KEY) {
          try {
            console.log("Using Lemonfox API for transcription...");
            const transcriptionResult = await transcribeVideo(videoPath);
            transcription = transcriptionResult.transcription;
            console.log("Transcription completed successfully");
          } catch (error) {
            console.error("Lemonfox transcription failed, using mock data:", error);
            transcription = generateMockTranscription("video.mp4", canvasMethod);
          }
        } else {
          console.log("Lemonfox API key not configured, using mock transcription");
          transcription = generateMockTranscription("video.mp4", canvasMethod);
        }
        
        // Check if OpenAI API key is available
        if (!process.env.OPENAI_API_KEY) {
          console.error("OpenAI API key not configured");
          // Fall back to mock data if no API key
          const mockAnalysis = {
            videoId,
            overallScore: Math.floor(Math.random() * 40) + 60,
            emotionScore: Math.floor(Math.random() * 40) + 60,
            convincabilityScore: Math.floor(Math.random() * 40) + 60,
            persuasionScore: Math.floor(Math.random() * 40) + 60,
            trustScore: Math.floor(Math.random() * 40) + 60,
            enthusiasmScore: Math.floor(Math.random() * 40) + 60,
            aiFeedback: "OpenAI API key not configured. Please add your API key to analyze videos.",
            transcription: transcription,
            behavioralSignals: {
              faceExpressions: ["confident", "engaging"],
              toneAnalysis: ["enthusiastic", "trustworthy"],
              bodyLanguage: ["open", "dynamic"]
            },
            pineconeVectorId: `vector_${videoId}_${Date.now()}`,
          };
          
          await storage.createVideoAnalysis(mockAnalysis);
          await storage.updateVideoStatus(videoId, "completed");
          return;
        }
        
        // Analyze video content using OpenAI
        const analysis = await analyzeVideoContent(transcription, canvasMethod);
        
        // Create analysis data with OpenAI results
        const analysisData = {
          videoId,
          overallScore: analysis.overallScore,
          emotionScore: analysis.emotionScore,
          convincabilityScore: analysis.convincabilityScore,
          persuasionScore: analysis.persuasionScore,
          trustScore: analysis.trustScore,
          enthusiasmScore: analysis.enthusiasmScore,
          aiFeedback: analysis.aiFeedback,
          transcription: transcription,
          behavioralSignals: {
            faceExpressions: ["confident", "engaging"],
            toneAnalysis: ["enthusiastic", "trustworthy"],
            bodyLanguage: ["open", "dynamic"],
            keyMoments: analysis.keyMoments
          },
          macAnalysis: analysis.macAnalysis,
          pineconeVectorId: `vector_${videoId}_${Date.now()}`,
        };

        await storage.createVideoAnalysis(analysisData);
        await storage.updateVideoStatus(videoId, "completed");
      } catch (error) {
        console.error("Error in AI analysis:", error);
        await storage.updateVideoStatus(videoId, "failed");
      }
    }, 3000); // 3 second delay to simulate processing

  } catch (error) {
    console.error("Error starting video analysis:", error);
    await storage.updateVideoStatus(videoId, "failed");
  }
}
