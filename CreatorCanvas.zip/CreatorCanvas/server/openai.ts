import OpenAI from "openai";
import { getMacPersonaAnalysis, MacAnalysis } from "./mac-persona";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface VideoAnalysisResult {
  overallScore: number;
  emotionScore: number;
  convincabilityScore: number;
  persuasionScore: number;
  trustScore: number;
  enthusiasmScore: number;
  aiFeedback: string;
  keyMoments: string[];
  macAnalysis?: MacAnalysis;
}

export async function analyzeVideoContent(
  transcription: string,
  canvasMethod: string
): Promise<VideoAnalysisResult> {
  try {
    const prompt = `You are an expert Canvas UGC (User-Generated Content) analyst. Analyze the following video transcription for the "${canvasMethod}" Canvas method.

Transcription:
${transcription}

Evaluate the content on these criteria (score 0-100):
1. Emotion: How well does the content evoke emotional response?
2. Convincability: How convincing and credible is the message?
3. Persuasion: How effectively does it persuade the viewer?
4. Trust: How trustworthy does the creator appear?
5. Enthusiasm: How energetic and passionate is the delivery?

Also provide:
- Overall score (weighted average)
- Specific feedback for improvement
- 3-5 key moments or quotes that stood out

Canvas UGC Methods context:
- Facetime Method: Personal, conversational style as if talking to a friend
- Lazy Girl Method: Effortless, relatable content with minimal production
- Tutorial Method: Educational, step-by-step guidance
- Hot Girl Commentary: Confident, opinion-based content with personality
- FOMO Method: Creates urgency and fear of missing out

Respond in JSON format with this structure:
{
  "overallScore": number,
  "emotionScore": number,
  "convincabilityScore": number,
  "persuasionScore": number,
  "trustScore": number,
  "enthusiasmScore": number,
  "aiFeedback": "detailed feedback string",
  "keyMoments": ["moment1", "moment2", "moment3"]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a Canvas UGC expert who analyzes content for storytelling effectiveness. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 1000
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    // Ensure all scores are between 0 and 100
    const scores = {
      emotionScore: Math.min(100, Math.max(0, Math.round(result.emotionScore || 0))),
      convincabilityScore: Math.min(100, Math.max(0, Math.round(result.convincabilityScore || 0))),
      persuasionScore: Math.min(100, Math.max(0, Math.round(result.persuasionScore || 0))),
      trustScore: Math.min(100, Math.max(0, Math.round(result.trustScore || 0))),
      enthusiasmScore: Math.min(100, Math.max(0, Math.round(result.enthusiasmScore || 0))),
    };
    
    // Get Mac's personalized analysis
    const macAnalysis = await getMacPersonaAnalysis(transcription, canvasMethod, scores);
    
    return {
      overallScore: Math.min(100, Math.max(0, Math.round(result.overallScore || 0))),
      ...scores,
      aiFeedback: result.aiFeedback || "Unable to generate feedback at this time.",
      keyMoments: result.keyMoments || [],
      macAnalysis
    };
  } catch (error) {
    console.error("Error analyzing video with OpenAI:", error);
    throw new Error("Failed to analyze video content");
  }
}

// Function to generate a mock transcription for testing
// In production, this would be replaced by actual video transcription service
export function generateMockTranscription(filename: string, canvasMethod: string): string {
  const mockTranscriptions: Record<string, string> = {
    "Facetime Method": `Hey guys! So I just had to share this with you because I've been using this new skincare routine for like two weeks now and oh my god, my skin has never looked better. 
    Like, I'm not even wearing foundation right now, can you believe it? 
    I was literally crying last month because my skin was breaking out so bad and nothing was working. 
    But then my friend Sarah told me about this Korean skincare method and I was skeptical at first but decided to try it anyway. 
    The key is layering - you start with a gentle cleanser, then essence, then serum, and finally moisturizer. 
    I do this every morning and night, and the difference is insane! 
    My husband even noticed and asked what I've been doing differently. 
    If you're struggling with your skin, you have to try this!`,
    
    "Lazy Girl Method": `Okay so if you're like me and hate complicated morning routines, this is for you. 
    I literally just roll out of bed, splash some water on my face, and use this one product - that's it. 
    It's this all-in-one serum that does everything. 
    I don't have time for 10-step routines, who does? 
    This takes me literally 30 seconds and I'm done. 
    Been doing this for a month and my skin looks just as good as when I was doing all those complicated steps. 
    Work smarter not harder, right?`,
    
    "Tutorial/How I Did This": `Step one: Start with a clean face. I'm using micellar water on a cotton pad. 
    Step two: Apply the vitamin C serum. Use about 3-4 drops and pat it into your skin, don't rub. 
    Step three: Wait 60 seconds for it to absorb. This is important! 
    Step four: Apply your hyaluronic acid serum. Same technique - pat, don't rub. 
    Step five: Finish with a lightweight moisturizer. I'm using this gel cream because it doesn't feel heavy. 
    That's it! Do this every morning and you'll see results in about 2 weeks. 
    Remember - consistency is key!`,
    
    "Hot Girl Commentary": `Listen, I'm so tired of these beauty gurus telling us we need 47 products to have good skin. 
    It's literally a scam. You know what cleared my skin? Drinking water and minding my business. 
    These companies want you to think you need all this stuff but your skin literally knows how to take care of itself. 
    I use soap and moisturizer. That's it. And my skin is glowing. 
    Stop letting them convince you that you need to spend $500 on skincare. 
    You're already beautiful, they just want your money. Period.`,
    
    "FOMO Method": `Guys, I'm not kidding - this serum is selling out everywhere! 
    I barely got my hands on the last bottle at Sephora yesterday. 
    Everyone on TikTok is talking about it and there's a reason why. 
    It literally transformed my skin in ONE WEEK. 
    I heard they're not restocking until next month so if you see it, grab it immediately. 
    My friend waited and now she can't find it anywhere. 
    I'm ordering three more bottles online right now before they're gone. 
    Don't say I didn't warn you!`
  };

  return mockTranscriptions[canvasMethod] || mockTranscriptions["Facetime Method"];
}