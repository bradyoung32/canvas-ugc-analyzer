import {
  users,
  videos,
  videoAnalyses,
  accessCodes,
  type User,
  type UpsertUser,
  type Video,
  type InsertVideo,
  type VideoAnalysis,
  type InsertVideoAnalysis,
  type AccessCode,
  type InsertAccessCode,
  type UpdateUserSettingsType,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, count, avg, max, sql } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserSettings(userId: string, settings: UpdateUserSettingsType): Promise<User>;
  
  // Access code operations
  validateAccessCode(code: string): Promise<AccessCode | undefined>;
  useAccessCode(code: string, userId: string): Promise<void>;
  
  // Video operations
  createVideo(video: InsertVideo): Promise<Video>;
  getVideo(id: number): Promise<Video | undefined>;
  getUserVideos(userId: string): Promise<Video[]>;
  updateVideoStatus(id: number, status: string): Promise<void>;
  
  // Video analysis operations
  createVideoAnalysis(analysis: InsertVideoAnalysis): Promise<VideoAnalysis>;
  getVideoAnalysis(videoId: number): Promise<VideoAnalysis | undefined>;
  getUserAnalyses(userId: string): Promise<(VideoAnalysis & Video)[]>;
  
  // Metrics operations
  getUserStats(userId: string): Promise<{
    totalVideos: number;
    avgScore: number;
    bestScore: number;
    thisWeekCount: number;
  }>;
  getUserCanvasMethodPerformance(userId: string): Promise<Array<{
    canvasMethod: string;
    avgScore: number;
    count: number;
  }>>
}

export class DatabaseStorage implements IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserSettings(userId: string, settings: UpdateUserSettingsType): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...settings, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Access code operations
  async validateAccessCode(code: string): Promise<AccessCode | undefined> {
    const [accessCode] = await db
      .select()
      .from(accessCodes)
      .where(and(eq(accessCodes.code, code), eq(accessCodes.isUsed, false)));
    return accessCode;
  }

  async useAccessCode(code: string, userId: string): Promise<void> {
    await db
      .update(accessCodes)
      .set({
        isUsed: true,
        usedBy: userId,
        usedAt: new Date(),
      })
      .where(eq(accessCodes.code, code));
  }

  // Video operations
  async createVideo(video: InsertVideo): Promise<Video> {
    const [newVideo] = await db.insert(videos).values(video).returning();
    return newVideo;
  }

  async getVideo(id: number): Promise<Video | undefined> {
    const [video] = await db.select().from(videos).where(eq(videos.id, id));
    return video;
  }

  async getUserVideos(userId: string): Promise<Video[]> {
    return await db
      .select()
      .from(videos)
      .where(eq(videos.userId, userId))
      .orderBy(desc(videos.createdAt));
  }

  async updateVideoStatus(id: number, status: string): Promise<void> {
    await db
      .update(videos)
      .set({ status, updatedAt: new Date() })
      .where(eq(videos.id, id));
  }

  // Video analysis operations
  async createVideoAnalysis(analysis: InsertVideoAnalysis): Promise<VideoAnalysis> {
    const [newAnalysis] = await db.insert(videoAnalyses).values(analysis).returning();
    return newAnalysis;
  }

  async getVideoAnalysis(videoId: number): Promise<VideoAnalysis | undefined> {
    const [analysis] = await db
      .select()
      .from(videoAnalyses)
      .where(eq(videoAnalyses.videoId, videoId));
    return analysis;
  }

  async getUserAnalyses(userId: string): Promise<any[]> {
    return await db
      .select()
      .from(videoAnalyses)
      .innerJoin(videos, eq(videoAnalyses.videoId, videos.id))
      .where(eq(videos.userId, userId))
      .orderBy(desc(videos.createdAt));
  }

  // Metrics operations
  async getUserStats(userId: string): Promise<{
    totalVideos: number;
    avgScore: number;
    bestScore: number;
    thisWeekCount: number;
    avgEmotionScore: number;
    avgConvincabilityScore: number;
    avgPersuasionScore: number;
    avgTrustScore: number;
    avgEnthusiasmScore: number;
    improvement: number;
  }> {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const [stats] = await db
      .select({
        totalVideos: count(videos.id),
        avgScore: avg(videoAnalyses.overallScore),
        bestScore: max(videoAnalyses.overallScore),
        avgEmotionScore: avg(videoAnalyses.emotionScore),
        avgConvincabilityScore: avg(videoAnalyses.convincabilityScore),
        avgPersuasionScore: avg(videoAnalyses.persuasionScore),
        avgTrustScore: avg(videoAnalyses.trustScore),
        avgEnthusiasmScore: avg(videoAnalyses.enthusiasmScore),
      })
      .from(videos)
      .leftJoin(videoAnalyses, eq(videos.id, videoAnalyses.videoId))
      .where(eq(videos.userId, userId));

    const [weekStats] = await db
      .select({
        thisWeekCount: count(videos.id),
      })
      .from(videos)
      .where(
        and(
          eq(videos.userId, userId),
          sql`${videos.createdAt} >= ${oneWeekAgo}`
        )
      );

    // Calculate improvement (mock calculation for now)
    const improvement = stats.totalVideos > 0 ? 12 : 0;

    return {
      totalVideos: stats.totalVideos || 0,
      avgScore: Number(stats.avgScore) || 0,
      bestScore: Number(stats.bestScore) || 0,
      thisWeekCount: weekStats.thisWeekCount || 0,
      avgEmotionScore: Number(stats.avgEmotionScore) || 0,
      avgConvincabilityScore: Number(stats.avgConvincabilityScore) || 0,
      avgPersuasionScore: Number(stats.avgPersuasionScore) || 0,
      avgTrustScore: Number(stats.avgTrustScore) || 0,
      avgEnthusiasmScore: Number(stats.avgEnthusiasmScore) || 0,
      improvement: improvement,
    };
  }

  async getUserCanvasMethodPerformance(userId: string): Promise<Array<{
    canvasMethod: string;
    avgScore: number;
    count: number;
  }>> {
    const results = await db
      .select({
        canvasMethod: videos.canvasMethod,
        avgScore: avg(videoAnalyses.overallScore),
        count: count(videos.id),
      })
      .from(videos)
      .leftJoin(videoAnalyses, eq(videos.id, videoAnalyses.videoId))
      .where(eq(videos.userId, userId))
      .groupBy(videos.canvasMethod)
      .orderBy(desc(avg(videoAnalyses.overallScore)));
    
    return results.map(r => ({
      ...r,
      avgScore: Number(r.avgScore) || 0
    }));
  }
}

export const storage = new DatabaseStorage();
